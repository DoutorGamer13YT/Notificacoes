package app.iosbanners

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.drawable.Drawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.Parcelable
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.NotificationListenerService.Ranking
import android.service.notification.StatusBarNotification
import android.util.Log
import java.util.concurrent.ConcurrentHashMap

/**
 * Recebe as notificações reais do sistema (API oficial NotificationListenerService)
 * e as repassa ao banner. Não armazena nem transmite o conteúdo.
 *
 * Funcionamento em segundo plano: o sistema mantém este serviço vinculado enquanto o acesso às
 * notificações estiver concedido; ele só consome CPU quando chega uma notificação (sem loops,
 * timers nem serviço em primeiro plano). Se o sistema (ou a One UI) o desconectar, pedimos a
 * reconexão em [onListenerDisconnected].
 *
 * Threads: o sistema chama [onNotificationPosted] na thread principal. A leitura do conteúdo e o
 * carregamento das imagens (trabalho que pode ser pesado em conversas longas) rodam numa thread de
 * trabalho única (ordem preservada); só o desenho do cartão volta à thread principal.
 */
class NotificationService : NotificationListenerService() {

    companion object {
        @Volatile
        var connected: Boolean = false

        @Volatile
        private var instance: NotificationService? = null

        /** Marca a notificação de teste enviada pelo próprio app (botão "Enviar teste"). */
        const val EXTRA_IS_TEST = "app.iosbanners.IS_TEST"
        private const val TAG = "IosBanners"

        /** Limites da prévia: nunca vai o histórico da conversa, só a mensagem mais recente, curta. */
        const val MAX_PREVIEW_CHARS = 120
        const val MAX_TITLE_CHARS = 60

        /** Texto genérico usado quando o conteúdo não deve aparecer com o aparelho bloqueado. */
        private const val HIDDEN_BODY = "Nova mensagem"

        /** Valor documentado de NotificationManager.VISIBILITY_NO_OVERRIDE: "o canal não define visibilidade". */
        private const val VISIBILITY_NO_OVERRIDE = -1000

        private val WHITESPACE = Regex("\\s+")

        /**
         * Remove a notificação original (se a opção estiver ligada). Chamado só depois que o
         * cartão estilo iOS apareceu de fato, para nunca ficar sem nenhuma das duas.
         */
        fun removeOriginalIfEnabled(key: String) {
            instance?.removeOriginal(key)
        }

        /**
         * Reavalia, pelas notificações que ainda estão na central, quais canais continuam com pop-up
         * original (chamado quando o app é aberto, para a lista refletir ajustes recém-feitos).
         */
        fun refreshPopupChannels() {
            instance?.reevaluateActive()
        }

        /**
         * Texto curto de uma linha: sem quebras de linha, no máximo [max] caracteres, com reticências.
         * Com [lastLineOnly], usa só a última linha com texto (apps de chat que acumulam uma mensagem
         * por linha no texto expandido: a mais recente é a última).
         */
        fun shortText(raw: CharSequence?, max: Int, lastLineOnly: Boolean = false): String {
            if (raw.isNullOrBlank()) return ""
            var s = raw.toString()
            if (lastLineOnly) {
                s = s.lineSequence().map { it.trim() }.lastOrNull { it.isNotEmpty() } ?: return ""
            }
            s = WHITESPACE.replace(s.trim(), " ")
            if (s.length <= max) return s
            var end = max - 1
            if (end > 0 && Character.isHighSurrogate(s[end - 1])) end--
            return s.substring(0, end).trimEnd() + "…"
        }
    }

    private enum class Route { NONE, OVERLAY, LOCK }

    private lateinit var overlay: BannerOverlay
    private lateinit var worker: HandlerThread
    private lateinit var workHandler: Handler
    private val mainHandler = Handler(Looper.getMainLooper())

    // Acessados pela thread principal e pela de trabalho.
    private val lastHash = ConcurrentHashMap<String, Int>()
    private val labelCache = ConcurrentHashMap<String, String>()

    /** Chaves que nós mesmos removemos (para não repetir o cartão se o app republicar igual). */
    private val removedByUs: MutableSet<String> = ConcurrentHashMap.newKeySet()

    /** Chaves da notificação de teste: ela sempre é removida depois do cartão, mesmo com a opção desligada. */
    private val testKeys: MutableSet<String> = ConcurrentHashMap.newKeySet()

    /**
     * Chaves cujo cartão do evento atual já apareceu e cuja original já foi removida por nós.
     * Se o app republicar exatamente o mesmo evento (mesma chave e mesmo conteúdo), a original volta
     * à central e ao pop-up: removemos de novo, em silêncio, sem mostrar outro cartão.
     */
    private val cardedKeys: MutableSet<String> = ConcurrentHashMap.newKeySet()

    /** "When" da notificação que originou o cartão atual de cada chave (identifica a mesma notificação). */
    private val lastWhen = ConcurrentHashMap<String, Long>()

    override fun onCreate() {
        super.onCreate()
        overlay = BannerOverlay(this)
        worker = HandlerThread("ios-banners-work").also { it.start() }
        workHandler = Handler(worker.looper)
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
            connected = false
        }
        mainHandler.removeCallbacksAndMessages(null)
        worker.quitSafely()
        overlay.release()
        super.onDestroy()
    }

    override fun onListenerConnected() {
        connected = true
        instance = this
    }

    override fun onListenerDisconnected() {
        connected = false
        if (instance === this) instance = null
        // Pede ao sistema para vincular o serviço de novo (permitido pela API; sem loop próprio),
        // mas só se o acesso ainda estiver concedido: com o acesso revogado não há o que reconectar.
        try {
            val component = ComponentName(this, NotificationService::class.java)
            val nm = getSystemService(NotificationManager::class.java)
            if (nm?.isNotificationListenerAccessGranted(component) == true) {
                NotificationListenerService.requestRebind(component)
            } else {
                Log.i(TAG, "Acesso às notificações revogado; serviço não será reconectado")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Não foi possível pedir a reconexão do serviço", e)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        val key = sbn?.key ?: return
        // Se fomos nós que removemos, mantém o hash: evita repetir o cartão se o app republicar o mesmo conteúdo.
        // Se foi o app (ou o usuário) que removeu, o próximo post com esta chave é um evento novo.
        if (!removedByUs.remove(key)) {
            lastHash.remove(key)
            cardedKeys.remove(key)
            lastWhen.remove(key)
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        // Proteção antecipada: se esta é a mesma notificação (mesma chave e mesmo "when") já convertida
        // em cartão, o app apenas a republicou. Removemos já, aqui mesmo, sem esperar a fila de trabalho,
        // para a original não ficar visível enquanto o processamento roda. Mudança de conteúdo costuma
        // trocar o "when", e então segue o caminho normal (que mostra o cartão novo).
        if (cardedKeys.contains(sbn.key) && lastWhen[sbn.key] == sbn.notification?.`when`) {
            removeOriginal(sbn.key)
        }
        // Sai logo da thread principal: nada de ler preferências, extras ou imagens aqui.
        workHandler.post {
            try {
                handle(sbn)
            } catch (t: Throwable) {
                Log.e(TAG, "Falha ao processar notificação", t)
            }
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        if (!Prefs.enabled(this)) return
        val n = sbn.notification ?: return
        val pkg = sbn.packageName
        val ownPackage = pkg == packageName

        // Do próprio app, só passa a notificação de teste.
        val extras = n.extras
        val isTest = ownPackage && extras?.getBoolean(EXTRA_IS_TEST, false) == true
        if (ownPackage && !isTest) return
        if (!ownPackage && !Prefs.isMonitored(this, pkg)) return

        // Ignora resumos de grupo, serviços em primeiro plano, mídia e progresso.
        // (Essas notificações nunca são removidas por este app.)
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if ((n.flags and (Notification.FLAG_ONGOING_EVENT or Notification.FLAG_FOREGROUND_SERVICE)) != 0) return
        when (n.category) {
            Notification.CATEGORY_TRANSPORT,
            Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_SYSTEM,
            Notification.CATEGORY_STATUS -> return
        }
        // Ligações, alarmes e navegação nunca são trocados nem removidos (vale também no modo "todos os apps").
        if (isCriticalAlert(n)) return
        if (extras == null) return

        // Registra (ou limpa) o aviso de "pop-up original ativo" deste canal. Só lê o ranking.
        if (!ownPackage) trackPopup(sbn)

        // Decide primeiro se algo poderá ser exibido; se não, não gasta CPU extraindo nada.
        val route = pickRoute()
        if (route == Route.NONE) return

        // Aparelho bloqueado com PIN/padrão/biometria: respeita a visibilidade da notificação na tela
        // de bloqueio. SECRET = o sistema também não mostra, então não mostramos nada. PRIVATE (o
        // padrão da maioria dos apps) = conteúdo só com a prévia ligada no app (o Android não deixa
        // um app ler a opção "ocultar conteúdo sensível" do sistema). PUBLIC = pode mostrar.
        var hideContent = false
        if (route == Route.LOCK && isDeviceSecure()) {
            when (effectiveVisibility(sbn, n)) {
                Notification.VISIBILITY_SECRET -> return
                Notification.VISIBILITY_PUBLIC -> Unit
                else -> hideContent = !Prefs.lockPreview(this)
            }
        }

        val appName = appLabel(pkg)
        val isChat = n.category == Notification.CATEGORY_MESSAGE

        var title = shortText(extras.getCharSequence(Notification.EXTRA_TITLE), MAX_TITLE_CHARS)
        // Texto expandido de apps de chat costuma acumular o histórico (uma mensagem por linha):
        // nesse caso vale a última linha, a mais recente, e não as primeiras.
        var body = shortText(extras.getCharSequence(Notification.EXTRA_BIG_TEXT), MAX_PREVIEW_CHARS, isChat)
        if (body.isEmpty()) {
            body = shortText(extras.getCharSequence(Notification.EXTRA_TEXT), MAX_PREVIEW_CHARS, isChat)
        }
        if (body.isEmpty()) {
            body = shortText(
                extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.lastOrNull(),
                MAX_PREVIEW_CHARS
            )
        }
        var avatarIcon: Icon? = null
        var messageCount = 0
        var stamp = n.`when`

        // Conversas (MessagingStyle): pega a última mensagem, o remetente e a foto.
        // Só a mensagem mais recente é lida do pacote: interpretar todas (até ~25, cada uma com
        // remetente e ícone) era trabalho à toa em conversas longas.
        @Suppress("DEPRECATION")
        val rawMessages = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (rawMessages != null && rawMessages.isNotEmpty()) {
            messageCount = rawMessages.size
            val lastOnly = arrayOf<Parcelable>(rawMessages[rawMessages.size - 1])
            val last = Notification.MessagingStyle.Message.getMessagesFromBundleArray(lastOnly).lastOrNull()
            if (last != null) {
                stamp = last.timestamp
                val lastText = last.text?.toString().orEmpty()
                val person = last.senderPerson
                val senderName = shortText(person?.name, MAX_TITLE_CHARS)
                val conversation = shortText(
                    extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE),
                    MAX_TITLE_CHARS
                )
                if (lastText.isNotBlank()) {
                    if (conversation.isNotEmpty()) {
                        title = conversation
                        body = shortText(
                            if (senderName.isNotEmpty()) "$senderName: $lastText" else lastText,
                            MAX_PREVIEW_CHARS
                        )
                    } else {
                        if (senderName.isNotEmpty()) title = senderName
                        body = shortText(lastText, MAX_PREVIEW_CHARS)
                    }
                }
                avatarIcon = person?.icon
            }
        }

        if (title.isBlank()) title = shortText(appName, MAX_TITLE_CHARS)
        if (title.isBlank() && body.isBlank()) return
        // Não repete a mesma frase no título e no texto.
        if (body.equals(title, ignoreCase = true)) body = ""

        // Evita repetir a mesma atualização da mesma notificação (antes de carregar imagens).
        // Em conversas, a hora da última mensagem identifica o evento (a hora da notificação pode
        // mudar quando o app apenas a republica).
        val hash = (title + "\u0000" + body + "\u0000" + messageCount + "\u0000" + stamp).hashCode()
        if (lastHash[sbn.key] == hash) {
            // Mesmo evento já tratado: não há cartão novo. Mas se o app republicou a original depois
            // de nós a termos removido, ela voltou; removemos de novo para não sobrar duas.
            // Só age se o cartão deste evento realmente apareceu (cardedKeys).
            if (cardedKeys.contains(sbn.key)) {
                val key = sbn.key
                mainHandler.post { removeOriginal(key) }
            }
            return
        }
        if (lastHash.size > 300) {
            lastHash.clear()
            cardedKeys.clear()
            lastWhen.clear()
        }
        lastHash[sbn.key] = hash
        // Evento novo para esta chave: ainda não há cartão confirmado para ele.
        cardedKeys.remove(sbn.key)
        lastWhen[sbn.key] = n.`when`

        if (hideContent) {
            // Só o app e um texto genérico (ou o texto público que o próprio app definiu para a
            // tela de bloqueio). Sem foto do contato.
            val publicText = shortText(
                n.publicVersion?.extras?.getCharSequence(Notification.EXTRA_TEXT),
                MAX_PREVIEW_CHARS
            )
            title = appName
            body = if (publicText.isEmpty() || publicText.equals(appName, ignoreCase = true)) HIDDEN_BODY else publicText
            avatarIcon = null
        }

        // Imagens só são carregadas quando o cartão realmente será montado.
        val appIcon: Drawable? = try {
            packageManager.getApplicationIcon(pkg)
        } catch (e: Exception) {
            null
        }
        val avatar: Drawable? = if (hideContent) null else loadIcon(avatarIcon) ?: loadIcon(n.getLargeIcon())

        val data = CardData(
            key = sbn.key,
            packageName = pkg,
            appName = appName,
            title = title,
            body = body,
            appIcon = appIcon,
            avatar = avatar,
            contentIntent = n.contentIntent,
            postTime = sbn.postTime
        )
        if (isTest) {
            if (testKeys.size > 20) testKeys.clear()
            testKeys.add(sbn.key)
        }
        // Só o desenho do cartão volta à thread principal.
        mainHandler.post {
            try {
                deliver(data, route)
            } catch (t: Throwable) {
                Log.e(TAG, "Falha ao exibir o cartão", t)
            }
        }
    }

    private fun isDeviceSecure(): Boolean =
        getSystemService(KeyguardManager::class.java)?.isDeviceSecure == true

    /**
     * Visibilidade na tela de bloqueio: a declarada pela notificação, trocada pela do canal quando
     * o canal define uma (API pública: Ranking.getChannel().getLockscreenVisibility()).
     * A escolha por app feita pelo usuário (Ranking.getVisibilityOverride) é API oculta do Android
     * e não está no SDK, por isso não é lida; nesse caso vale o padrão seguro (a prévia só aparece
     * com a opção do app ligada, ou se a notificação for PUBLIC).
     */
    private fun effectiveVisibility(sbn: StatusBarNotification, n: Notification): Int {
        var v = n.visibility
        try {
            val r = Ranking()
            if (currentRanking.getRanking(sbn.key, r)) {
                val channelVis = r.channel?.lockscreenVisibility ?: VISIBILITY_NO_OVERRIDE
                if (channelVis != VISIBILITY_NO_OVERRIDE) v = channelVis
            }
        } catch (e: Exception) {
            // Sem o ranking, vale a visibilidade declarada pelo app.
        }
        return v
    }

    private fun loadIcon(icon: Icon?): Drawable? = try {
        icon?.loadDrawable(this)
    } catch (e: Exception) {
        null
    }

    private fun appLabel(pkg: String): String {
        labelCache[pkg]?.let { return it }
        val label = try {
            val pm = packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        if (labelCache.size > 100) labelCache.clear()
        labelCache[pkg] = label
        return label
    }

    /** Escolhe onde exibir conforme o estado da tela; NONE se nada puder ser exibido agora. */
    private fun pickRoute(): Route {
        val pm = getSystemService(PowerManager::class.java)
        val km = getSystemService(KeyguardManager::class.java)
        val screenOn = pm?.isInteractive != false
        val locked = km?.isKeyguardLocked == true
        val canDraw = Settings.canDrawOverlays(this)
        return when {
            screenOn && !locked -> if (canDraw) Route.OVERLAY else Route.NONE
            // Experimental: com a tela apagada ou bloqueada, mostra só o cartão sobre fundo preto
            // (não é o AOD; com a tela apagada acende fraco). A original só é removida depois que
            // o cartão aparecer. Aqui a condição é "tela apagada OU bloqueada", o que sobra do caso acima.
            Prefs.lockCard(this) && canDraw -> Route.LOCK
            else -> Route.NONE
        }
    }

    private fun deliver(data: CardData, route: Route) {
        when (route) {
            Route.OVERLAY -> {
                // Só remove a original se o nosso cartão realmente apareceu.
                if (overlay.show(data)) removeOriginal(data.key)
            }
            Route.LOCK -> {
                try {
                    CardStore.pending = data
                    val i = Intent(this, LockCardActivity::class.java)
                    i.addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION
                    )
                    startActivity(i)
                } catch (e: Exception) {
                    Log.w(TAG, "Não foi possível abrir o cartão na tela bloqueada", e)
                }
            }
            Route.NONE -> Unit
        }
    }

    private fun removeOriginal(key: String) {
        val isTestKey = testKeys.remove(key)
        // A notificação de teste é só nossa: sai sempre, para não sobrar na central de notificações.
        if (!isTestKey) {
            if (!Prefs.exclusiveMode(this)) return
            // Modo exclusivo: só remove a original que faria pop-up. Se o canal já está sem pop-up,
            // ela fica na central, com som e respostas rápidas, e não há pop-up duplicado a evitar.
            if (!originalWouldPopUp(key)) return
        }
        try {
            if (removedByUs.size > 100) removedByUs.clear()
            removedByUs.add(key)
            cardedKeys.add(key)
            cancelNotification(key)
        } catch (e: Exception) {
            removedByUs.remove(key)
            cardedKeys.remove(key)
            Log.w(TAG, "Não foi possível remover a original", e)
        }
    }

    /** Estado do pop-up da original, lido do ranking atual do sistema (APIs públicas do listener). */
    private class PopupInfo(val popsUp: Boolean, val channelId: String, val channelName: String)

    private fun popupInfo(key: String): PopupInfo? {
        return try {
            val r = Ranking()
            if (!currentRanking.getRanking(key, r)) return null
            val importance = r.importance
            // IMPORTANCE_HIGH ou mais: faz som e aparece como pop-up. IMPORTANCE_DEFAULT: som, sem pop-up.
            // Fora do modo "Não perturbe" (matchesInterruptionFilter). Importância desconhecida: assume pop-up.
            // Com o ajuste global de pop-ups desligado (veja SystemPopups), nenhuma original faz pop-up.
            val popsUp = (importance == NotificationManager.IMPORTANCE_UNSPECIFIED ||
                importance >= NotificationManager.IMPORTANCE_HIGH) && r.matchesInterruptionFilter() &&
                !SystemPopups.disabled(this)
            val channel = r.channel
            var id = channel?.id.orEmpty()
            var name = channel?.name?.toString().orEmpty()
            // Canais de conversa levam o nome do contato: não guardamos; o ajuste é o da página do app.
            if (Build.VERSION.SDK_INT >= 30 && channel?.conversationId != null) {
                id = ""
                name = "Conversas"
            }
            PopupInfo(popsUp, id, name)
        } catch (e: Exception) {
            null
        }
    }

    /** Sem ranking disponível, assume que o pop-up aparece (é o lado seguro: evita duplicar). */
    private fun originalWouldPopUp(key: String): Boolean = popupInfo(key)?.popsUp ?: true

    private fun trackPopup(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg == packageName || !Prefs.isMonitored(this, pkg)) return
        val info = popupInfo(sbn.key) ?: return
        PopupChannels.update(this, pkg, info.channelId, info.channelName, info.popsUp)
    }

    /**
     * Ligações, alarmes e navegação, ou qualquer aviso com tela cheia (chamadas recebidas, despertador):
     * são importantes demais para trocar por um cartão ou remover.
     */
    private fun isCriticalAlert(n: Notification): Boolean {
        if (n.fullScreenIntent != null) return true
        return when (n.category) {
            Notification.CATEGORY_CALL,
            Notification.CATEGORY_ALARM,
            Notification.CATEGORY_NAVIGATION -> true
            else -> false
        }
    }

    private fun reevaluateActive() {
        try {
            val list = activeNotifications ?: return
            for (sbn in list) {
                val n = sbn.notification ?: continue
                if ((n.flags and (Notification.FLAG_GROUP_SUMMARY or Notification.FLAG_ONGOING_EVENT or
                        Notification.FLAG_FOREGROUND_SERVICE)) != 0
                ) continue
                if (isCriticalAlert(n)) continue
                trackPopup(sbn)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Não foi possível reavaliar as notificações ativas", e)
        }
    }
}
