package app.iosbanners

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.view.WindowManager

class MainActivity : Activity() {

    private companion object {
        const val REQ_POST_NOTIFICATIONS = 10
        const val CHANNEL_TEST = "ios_banners_test"
        val CARD_BG = Color.rgb(28, 28, 30)
        val TEXT_2 = Color.argb(170, 235, 235, 245)
        val ACCENT = Color.rgb(10, 132, 255)
        val GRAY_BTN = Color.rgb(58, 58, 60)
        val GOOD = Color.rgb(48, 209, 88)
        val BAD = Color.rgb(255, 69, 58)
    }

    private var binding = false

    /** Lógica da troca de modo (testada na JVM); aqui só a interface chama. */
    private val controller by lazy { ModeController(AndroidModeEnvironment(this)) }

    private class ModeOption(val box: LinearLayout, val marker: TextView, val title: String)

    private lateinit var modeIos: ModeOption
    private lateinit var modeSamsung: ModeOption
    private lateinit var modeStatusView: TextView
    private lateinit var modeFixBtn: Button

    private lateinit var darkSwitch: Switch
    private lateinit var blurSwitch: Switch
    private lateinit var exclusiveSwitch: Switch
    private lateinit var exclusiveStatus: TextView
    private lateinit var exclusiveFixBtn: Button
    private lateinit var popupList: LinearLayout
    private lateinit var systemPopupStatus: TextView
    private lateinit var systemPopupBtn: Button
    private lateinit var lockSwitch: Switch
    private lateinit var lockPreviewSwitch: Switch
    private lateinit var accessStatus: TextView
    private lateinit var overlayStatus: TextView
    private lateinit var appsCount: TextView
    private lateinit var allAppsSwitch: Switch
    private lateinit var chooseAppsBtn: Button
    private lateinit var previewHolder: FrameLayout
    private lateinit var diagView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(24), dp(16), dp(32))
        scroll.addView(col)
        setContentView(scroll)

        text(col, "iOS Banners", 28f, Color.WHITE, bold = true)
        text(col, "Cartão de notificação em estilo iOS para as notificações reais do Android.", 14f, TEXT_2)
            .setPadding(0, dp(4), 0, dp(16))
        creditBadge(col)

        // --- Substituir notificações nativas ---
        val cm = section(col, "Substituir notificações nativas")
        modeIos = modeOption(
            cm, "ATIVADO",
            "Mostra as notificações pelo iOS Banners. A original continua sendo recebida em segundo plano (é " +
                "a partir dela que o cartão é montado) e só é dispensada, de forma seletiva, depois que o cartão " +
                "aparece e quando ela faria pop-up e a remoção é permitida e segura."
        ) { onModeChosen(NotificationMode.IOS) }
        modeSamsung = modeOption(
            cm, "DESATIVADO",
            "Interrompe a apresentação personalizada e restaura o comportamento normal da Samsung: as " +
                "notificações nativas aparecem como sempre. O app não lê, não mostra e não remove nenhuma notificação."
        ) { onModeChosen(NotificationMode.SAMSUNG) }
        modeStatusView = text(cm, "", 14f, Color.WHITE)
        modeStatusView.setPadding(0, dp(4), 0, 0)
        modeFixBtn = button(cm, "Conceder o que falta", true) { openMissingRequirement() }
        text(
            cm,
            "A escolha é aplicada na hora, fica salva e continua valendo depois de fechar o app ou reiniciar o " +
                "celular.\n\nLimites do modo ATIVADO (do Android e da One UI, não do app): ligações, alarmes, " +
                "navegação, avisos de tela cheia, mídia, progresso, serviços em andamento, resumos de grupo e " +
                "notificações que o app de origem marca como não dispensáveis nunca são removidos; lembretes e " +
                "eventos viram cartão mas a original fica. O Android só deixa o app dispensar uma notificação " +
                "depois de ela ser publicada, então o pop-up original pode piscar antes do cartão. Um app comum " +
                "não consegue desativar as notificações nem os canais de outros apps (só você pode, nas " +
                "configurações do sistema); este app não pede root, não usa cancelAllNotifications() e não mexe " +
                "em canais. Por isso o modo ATIVADO NÃO remove todas as notificações nativas. As que já foram " +
                "dispensadas não voltam à central ao DESATIVAR (o Android não permite republicar notificações de " +
                "outros apps); as próximas chegam normalmente. No cartão, deslize para baixo para ver as ações " +
                "do app de origem (as de resposta por texto não são suportadas: toque no cartão para abrir o " +
                "app). Não verificado em aparelho.",
            12.5f, TEXT_2
        ).setPadding(0, dp(10), 0, 0)

        // --- Permissões ---
        val c1 = section(col, "Permissões")
        text(
            c1,
            "Só duas são necessárias para o modo ATIVADO: acesso às notificações e exibir sobre outros apps. " +
                "O app não concede nada sozinho: abre as configurações oficiais do Android.",
            12.5f, TEXT_2
        ).setPadding(0, 0, 0, dp(6))
        accessStatus = text(c1, "", 14f, Color.WHITE)
        accessStatus.setPadding(0, dp(10), 0, 0)
        button(c1, "Conceder acesso às notificações", true) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        text(
            c1,
            "Se o Android bloquear (\"configuração restrita\"), abra \"Informações do app\" abaixo, " +
                "toque nos três pontos e escolha \"Permitir configurações restritas\".",
            12.5f, TEXT_2
        ).setPadding(0, dp(6), 0, 0)
        overlayStatus = text(c1, "", 14f, Color.WHITE)
        overlayStatus.setPadding(0, dp(12), 0, 0)
        button(c1, "Permitir exibir sobre outros apps", true) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }

        // --- Notificação exclusiva ---
        val cx = section(col, "Notificação exclusiva")
        exclusiveSwitch = switchRow(
            cx, "Modo de notificação exclusiva",
            "Só o cartão estilo iOS aparece como pop-up. Quando o pop-up original de um app está ativo, ele é " +
                "removido logo depois que o cartão aparece. Canais sem pop-up mantêm a notificação na central, " +
                "com som e respostas rápidas. Funciona em segundo plano, sem esta tela aberta."
        ) {
            Prefs.setExclusiveMode(this, it)
            if (it && Prefs.notificationMode(this) == NotificationMode.IOS) openMissingRequirement()
            renderExclusive()
        }
        exclusiveStatus = text(cx, "", 14f, Color.WHITE)
        exclusiveStatus.setPadding(0, dp(8), 0, 0)
        exclusiveFixBtn = button(cx, "Conceder o que falta", true) { openMissingRequirement() }
        text(cx, "Pop-ups do sistema (somente leitura)", 15.5f, Color.WHITE, bold = true).setPadding(0, dp(14), 0, 0)
        systemPopupStatus = text(cx, "", 13.5f, Color.WHITE)
        systemPopupStatus.setPadding(0, dp(4), 0, 0)
        systemPopupBtn = button(cx, "Restaurar os pop-ups do sistema", false) { onSystemPopupsClick() }
        text(
            cx,
            "Este app NÃO desliga pop-ups do sistema: o ajuste global afetaria todos os apps, inclusive " +
                "chamadas e alarmes, e a permissão WRITE_SECURE_SETTINGS não é uma forma segura nem comprovada de " +
                "desativar notificações de outros apps. Ela só é verificada aqui e usada para restaurar o ajuste se " +
                "uma versão anterior do app o tiver desligado. O botão acima só aparece nesse caso. Para restaurar " +
                "sem o app: adb shell settings put global heads_up_notifications_enabled 1",
            12.5f, TEXT_2
        ).setPadding(0, dp(6), 0, 0)
        text(cx, "Pop-ups originais ainda ativos", 15.5f, Color.WHITE, bold = true).setPadding(0, dp(14), 0, 0)
        text(
            cx,
            "O Android só deixa o próprio usuário mudar os canais de outros apps. Para manter a notificação na " +
                "central, com som e resposta rápida, e tirar só o pop-up, toque no botão do canal e deixe-o em " +
                "\"Padrão\" (som, sem pop-up) em vez de \"Urgente\"; na Samsung o nome pode variar " +
                "(por exemplo, desligar \"Mostrar como pop-up\"). Depois do ajuste, o canal sai desta lista " +
                "quando chegar a próxima notificação dele.",
            12.5f, TEXT_2
        ).setPadding(0, dp(4), 0, 0)
        popupList = LinearLayout(this)
        popupList.orientation = LinearLayout.VERTICAL
        cx.addView(
            popupList,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        button(cx, "Limpar lista", false) {
            PopupChannels.clear(this)
            renderExclusive()
        }
        text(
            cx,
            "Limites: o pop-up original só pode ser removido depois de aparecer (pode piscar), e remover uma " +
                "notificação pode cortar o som dela e tirá-la das respostas rápidas. Um app comum não consegue " +
                "desligar os pop-ups por app: isso só o usuário faz. Só o ajuste global acima chega perto, e exige uma permissão concedida por adb.",
            12.5f, TEXT_2
        ).setPadding(0, dp(10), 0, 0)

        // --- Aparência e opções ---
        val c2 = section(col, "Aparência e opções")
        darkSwitch = switchRow(c2, "Cartão escuro (AMOLED)", "Desligado = cartão claro.") {
            Prefs.setDarkCard(this, it)
            refreshPreview()
        }
        blurSwitch = switchRow(
            c2, "Desfoque do fundo (experimental)",
            "Usa o desfoque do sistema quando disponível; pode cobrir a janela inteira em vez do cartão arredondado."
        ) {
            Prefs.setBlur(this, it)
            refreshPreview()
        }
        lockSwitch = switchRow(
            c2, "Só o cartão com a tela apagada ou bloqueada (experimental)",
            "Se a notificação chegar com a tela apagada ou bloqueada, ela acende bem fraca, sem relógio nem barras, " +
                "só com o cartão sobre fundo preto, na mesma posição do banner, com só uma prévia curta da " +
                "mensagem mais recente. NÃO é o AOD: a tela fica ligada " +
                "por até 12 s (ou até o tempo limite do sistema). Não verificado em aparelho."
        ) { Prefs.setLockCard(this, it) }
        lockPreviewSwitch = switchRow(
            c2, "Prévia com o aparelho protegido por PIN/biometria",
            "Desligado: com PIN, padrão ou biometria, o cartão da tela bloqueada mostra só o nome do app e " +
                "\"Nova mensagem\". Ligado: mostra uma prévia curta (até ${NotificationService.MAX_PREVIEW_CHARS} " +
                "caracteres) da mensagem mais recente. O Android não deixa o app ler a sua opção \"ocultar conteúdo " +
                "sensível\"; ligue só se você já deixa o conteúdo visível na tela de bloqueio do sistema. " +
                "Notificações marcadas como secretas pelo app nunca aparecem."
        ) { Prefs.setLockPreview(this, it) }

        // --- Apps ---
        val c3 = section(col, "Aplicativos monitorados")
        allAppsSwitch = switchRow(
            c3, "Todos os apps",
            "Mostra o cartão para as notificações de qualquer app, exceto ligações, alarmes, navegação, mídia " +
                "e serviços em andamento (esses nunca são trocados nem removidos). Desligue para escolher só alguns apps."
        ) {
            Prefs.setAllApps(this, it)
            renderApps()
        }
        appsCount = text(c3, "", 14f, Color.WHITE)
        chooseAppsBtn = button(c3, "Escolher aplicativos", true) {
            startActivity(Intent(this, AppPickerActivity::class.java))
        }

        // --- Prévia ---
        val c4 = section(col, "Prévia")
        text(c4, "Exemplo de layout (não é uma notificação real).", 12.5f, TEXT_2)
            .setPadding(0, 0, 0, dp(10))
        previewHolder = FrameLayout(this)
        c4.addView(previewHolder)

        // --- Teste ---
        val c5 = section(col, "Teste")
        button(c5, "Enviar notificação de teste", true) { sendTest() }
        text(
            c5,
            "O app envia uma notificação real de si mesmo; o serviço a recebe como qualquer outra. " +
                "Mantenha o celular desbloqueado para ver o cartão.",
            12.5f, TEXT_2
        ).setPadding(0, dp(6), 0, 0)

        // --- Diagnóstico ---
        val c6 = section(col, "Diagnóstico")
        diagView = text(c6, "", 13f, Color.WHITE)
        diagView.typeface = Typeface.MONOSPACE
        button(c6, "Informações do app (configurações restritas)", false) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
        button(c6, "Ajustar uso de bateria", false) { openBatterySettings() }
        text(
            c6,
            "Para o serviço não ser suspenso: permita \"Sem restrição\" aqui e, na Samsung, confira em " +
                "Configurações → Bateria → Limites de uso em segundo plano (os nomes variam conforme a One UI) " +
                "se o app não está em \"Apps em suspensão\"/\"suspensão profunda\". " +
                "O app não usa serviço em primeiro plano nem tarefas periódicas: só trabalha quando chega uma notificação.",
            12.5f, TEXT_2
        ).setPadding(0, dp(6), 0, 0)

        // --- AOD ---
        val c7 = section(col, "Sobre o Always On Display (AOD)")
        text(
            c7,
            "O AOD da Samsung é desenhado pelo próprio sistema e só mostra os ícones das notificações não lidas. " +
                "Não existe API pública do Android nem da One UI para um app mudar a aparência disso, " +
                "então este app NÃO altera o AOD nativo.\n\n" +
                "O que ele faz: (1) mostra o cartão estilo iOS por cima do que estiver na tela, com o celular " +
                "ligado e desbloqueado; (2) com a tela apagada, acende a tela bem fraca só com o cartão sobre " +
                "fundo preto (no AMOLED o preto fica apagado). Essa segunda opção é uma tela comum do app, " +
                "não o AOD: a tela de fato liga até o tempo limite do sistema. Não foi verificada em aparelho.",
            13.5f, Color.WHITE
        )
    }

    override fun onResume() {
        super.onResume()
        rebindListenerIfNeeded()
        try {
            controller.reconcile()
        } catch (e: Exception) {
            // Sem ação: a tela mostra o estado real logo abaixo.
        }
        refresh()
    }

    /** Se o acesso foi concedido mas o serviço está desconectado, pede ao sistema que o vincule de novo. */
    private fun rebindListenerIfNeeded() {
        if (listenerGranted() && !NotificationService.connected) {
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(this, NotificationService::class.java)
                )
            } catch (e: Exception) {
                // Sem ação: o diagnóstico mostra o estado real.
            }
        }
    }

    /** Pede "Sem restrição de bateria" direto; se o sistema não permitir, abre a lista de otimização. */
    private fun openBatterySettings() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
                return
            } catch (e: Exception) {
                // Cai para a lista de otimização de bateria.
            }
        }
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            toast("Abra Configurações → Bateria e deixe este app sem restrição.")
        }
    }

    private fun refresh() {
        binding = true
        darkSwitch.isChecked = Prefs.darkCard(this)
        blurSwitch.isChecked = Prefs.blur(this)
        exclusiveSwitch.isChecked = Prefs.exclusiveMode(this)
        lockSwitch.isChecked = Prefs.lockCard(this)
        lockPreviewSwitch.isChecked = Prefs.lockPreview(this)
        binding = false

        val access = listenerGranted()
        accessStatus.text = if (access) "Acesso às notificações: ativo" else "Acesso às notificações: inativo"
        accessStatus.setTextColor(if (access) GOOD else BAD)
        val overlay = Settings.canDrawOverlays(this)
        overlayStatus.text = if (overlay) "Exibir sobre outros apps: permitido" else "Exibir sobre outros apps: não permitido"
        overlayStatus.setTextColor(if (overlay) GOOD else BAD)

        allAppsSwitch.isChecked = Prefs.allApps(this)
        renderApps()
        NotificationService.refreshPopupChannels()
        renderMode()
        renderExclusive()
        renderSystemPopups()
        diagView.text = diagnostics()
        refreshPreview()
    }

    /** Abre a tela do sistema da primeira permissão que falta. Devolve true se abriu alguma. */
    private fun openMissingRequirement(): Boolean {
        val intent: Intent
        if (!listenerGranted()) {
            toast("Falta conceder o acesso às notificações.")
            intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        } else if (!Settings.canDrawOverlays(this)) {
            toast("Falta permitir exibir sobre outros apps.")
            intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        } else {
            return false
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast("Não foi possível abrir as configurações do sistema.")
        }
        return true
    }

    /** Estado do modo exclusivo (requisitos) e lista dos canais com pop-up original ativo. */
    private fun renderExclusive() {
        val on = Prefs.exclusiveMode(this)
        val samsung = Prefs.notificationMode(this) == NotificationMode.SAMSUNG
        val access = listenerGranted()
        val overlay = Settings.canDrawOverlays(this)
        val missing = ArrayList<String>()
        if (!access) missing.add("acesso às notificações")
        if (!overlay) missing.add("exibir sobre outros apps")
        if (samsung) {
            exclusiveStatus.text = "Em pausa: \"Substituir notificações nativas\" está DESATIVADO e nenhuma notificação original é removida."
            exclusiveStatus.setTextColor(TEXT_2)
        } else if (!on) {
            exclusiveStatus.text = "Desligado: a notificação original continua aparecendo junto com o cartão."
            exclusiveStatus.setTextColor(TEXT_2)
        } else if (missing.isEmpty()) {
            exclusiveStatus.text = "Ativo. Requisitos: tudo concedido."
            exclusiveStatus.setTextColor(GOOD)
        } else {
            exclusiveStatus.text = "Ligado, mas ainda falta: " + missing.joinToString(", ") + "."
            exclusiveStatus.setTextColor(BAD)
        }
        exclusiveFixBtn.visibility = if (on && !samsung && (!access || !overlay)) View.VISIBLE else View.GONE

        popupList.removeAllViews()
        val entries = PopupChannels.list(this).sortedBy { appLabelOf(it.pkg).lowercase() }
        if (SystemPopups.disabled(this)) {
            text(popupList, "Pop-ups do sistema desligados: nenhum canal faz pop-up original.", 13.5f, TEXT_2)
                .setPadding(0, dp(10), 0, 0)
        } else if (entries.isEmpty()) {
            text(popupList, "Nenhum pop-up original ativo detectado até agora.", 13.5f, TEXT_2)
                .setPadding(0, dp(10), 0, 0)
        } else {
            for (e in entries) {
                val channel = if (e.channelName.isNotEmpty()) e.channelName else "canal sem nome"
                text(popupList, appLabelOf(e.pkg) + " — " + channel, 14f, Color.WHITE)
                    .setPadding(0, dp(10), 0, 0)
                button(popupList, "Desativar o pop-up deste canal", false) { openChannelSettings(e) }
            }
        }
    }

    // ---------- Modo de notificações ----------

    private fun requirementLabel(r: Requirement): String = when (r) {
        Requirement.LISTENER_ACCESS -> "acesso às notificações"
        Requirement.OVERLAY_PERMISSION -> "exibir sobre outros apps"
    }

    /** Estado efetivo do modo: diz a verdade, inclusive quando o modo iOS está escolhido mas sem permissões. */
    private fun renderMode() {
        val st = controller.status()
        styleModeOption(modeIos, st.mode == NotificationMode.IOS)
        styleModeOption(modeSamsung, st.mode == NotificationMode.SAMSUNG)
        when {
            st.mode == NotificationMode.SAMSUNG -> {
                modeStatusView.text =
                    "Atual: DESATIVADO (notificações originais da Samsung). O cartão está desligado e nada é removido."
                modeStatusView.setTextColor(GOOD)
            }
            st.presenting -> {
                modeStatusView.text =
                    "Atual: ATIVADO (funcionando). Cartão ligado; a original só é dispensada depois do cartão, " +
                        "quando faria pop-up e quando a remoção é permitida."
                modeStatusView.setTextColor(GOOD)
            }
            else -> {
                modeStatusView.text = "ATIVADO selecionado, mas ainda falta: " +
                    st.missing.joinToString(", ") { requirementLabel(it) } +
                    ". Enquanto faltar, nada é exibido nem removido e as notificações originais continuam normais."
                modeStatusView.setTextColor(BAD)
            }
        }
        val needsSystemScreen = st.mode == NotificationMode.IOS &&
            (st.missing.contains(Requirement.LISTENER_ACCESS) || st.missing.contains(Requirement.OVERLAY_PERMISSION))
        modeFixBtn.visibility = if (needsSystemScreen) View.VISIBLE else View.GONE
    }

    /** Toque numa das duas opções: grava, aplica na hora e mostra o resultado. */
    private fun onModeChosen(target: NotificationMode) {
        val result = try {
            controller.select(target)
        } catch (e: Exception) {
            null
        }
        refresh()
        if (result == null) {
            toast("Não foi possível trocar o modo. Tente de novo.")
            return
        }
        if (!result.ok) {
            toast(result.notes.firstOrNull() ?: "Não foi possível trocar o modo.")
            return
        }
        val parts = ArrayList<String>()
        parts.add(
            if (target == NotificationMode.IOS) "Substituir notificações nativas: ATIVADO."
            else "Substituir notificações nativas: DESATIVADO (notificações originais)."
        )
        parts.addAll(result.notes)
        if (target == NotificationMode.IOS && result.missing.isNotEmpty()) {
            showMissingDialog(result.missing)
        } else {
            toast(parts.joinToString(" "))
            // O app mexeu no pop-up do sistema e não conseguiu devolver: mostra o comando para restaurar.
            if (result.popupsRestorePending) showGrantInstructions(true)
        }
    }

    /** Permissão faltando: explica e leva às configurações oficiais do Android (nada é concedido sozinho). */
    private fun showMissingDialog(missing: List<Requirement>) {
        val labels = missing.joinToString(", ") { requirementLabel(it) }
        val builder = AlertDialog.Builder(this)
            .setTitle("Falta permissão para o modo ATIVADO")
            .setMessage(
                "\"Substituir notificações nativas\" ficou ATIVADO, mas ainda falta: $labels.\n\nEnquanto faltar, nada é exibido " +
                    "nem removido e as notificações originais continuam aparecendo normalmente. Quem concede " +
                    "é você, nas configurações oficiais do Android."
            )
        if (missing.contains(Requirement.LISTENER_ACCESS) || missing.contains(Requirement.OVERLAY_PERMISSION)) {
            builder.setPositiveButton("Abrir configurações") { _, _ -> openMissingRequirement() }
        }
        builder.setNegativeButton("Agora não", null)
        builder.show()
    }

    /** Opção selecionável: ○ ou ● (conforme a escolha), título e explicação curta; a caixa toda é clicável. */
    private fun modeOption(parent: LinearLayout, title: String, desc: String, onClick: () -> Unit): ModeOption {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(14), dp(12), dp(14), dp(12))
        box.isClickable = true
        box.isFocusable = true
        box.setOnClickListener { onClick() }

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val marker = TextView(this)
        marker.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        marker.setPadding(0, 0, dp(10), 0)
        head.addView(marker)
        val t = TextView(this)
        t.text = title
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
        t.setTextColor(Color.WHITE)
        t.paint.isFakeBoldText = true
        head.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(head)

        val d = TextView(this)
        d.text = desc
        d.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        d.setTextColor(TEXT_2)
        d.setPadding(0, dp(6), 0, 0)
        box.addView(d)

        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(8)
        parent.addView(box, lp)
        return ModeOption(box, marker, title)
    }

    private fun styleModeOption(o: ModeOption, selected: Boolean) {
        val bg = rounded(Color.rgb(44, 44, 46), 14)
        bg.setStroke(dp(2), if (selected) ACCENT else Color.TRANSPARENT)
        o.box.background = bg
        o.box.isSelected = selected
        o.box.contentDescription = o.title + if (selected) ", selecionado" else ", não selecionado"
        o.marker.text = if (selected) "●" else "○"
        o.marker.setTextColor(if (selected) ACCENT else TEXT_2)
    }

    private fun renderApps() {
        val all = Prefs.allApps(this)
        appsCount.text =
            if (all) "Todos os aplicativos" else "${Prefs.monitoredApps(this).size} aplicativo(s) monitorado(s)"
        chooseAppsBtn.visibility = if (all) View.GONE else View.VISIBLE
    }

    private fun renderSystemPopups() {
        val perm = SystemPopups.hasPermission(this)
        val off = SystemPopups.disabled(this)
        systemPopupStatus.text = "Pop-ups do sistema: " + (if (off) "DESLIGADOS (todos os apps)" else "ligados (normal)") +
            "\nPermissão WRITE_SECURE_SETTINGS: " + (if (perm) "concedida" else "não concedida (só por adb; opcional)")
        systemPopupStatus.setTextColor(if (off) BAD else Color.WHITE)
        // Só há o que restaurar quando o ajuste global está desligado.
        systemPopupBtn.visibility = if (off) View.VISIBLE else View.GONE
    }

    /** Restaurar (única ação deste bloco): religa o ajuste global, só por pedido do usuário. */
    private fun onSystemPopupsClick() {
        when (controller.restoreSystemPopups()) {
            PopupsOutcome.DONE -> {
                toast("Pop-ups do sistema restaurados.")
                refresh()
            }
            PopupsOutcome.NEEDS_PERMISSION -> showGrantInstructions(true)
            PopupsOutcome.FAILED -> toast("O sistema recusou a alteração.")
        }
    }

    private fun showGrantInstructions(restore: Boolean) {
        val grant = "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
        val back = "adb shell settings put global " + SystemPopups.KEY + " 1"
        val msg = StringBuilder()
        msg.append("Esta permissão não tem tela de ativação: o Android só a concede por adb, uma única vez, ")
        msg.append("num computador com a depuração USB ligada (ou pela depuração sem fio, com um app de terminal ")
        msg.append("no próprio celular; não testado aqui).\n\n")
        msg.append(grant)
        if (restore) {
            msg.append("\n\nPara restaurar os pop-ups sem a permissão:\n").append(back)
        }
        AlertDialog.Builder(this)
            .setTitle("Permissão necessária")
            .setMessage(msg.toString())
            .setPositiveButton("Copiar comando") { _, _ -> copyToClipboard(grant) }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun copyToClipboard(value: String) {
        val cm = getSystemService(ClipboardManager::class.java)
        cm?.setPrimaryClip(ClipData.newPlainText("adb", value))
        toast("Comando copiado.")
    }

    private fun appLabelOf(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    /** Abre o ajuste do canal no sistema (só o usuário pode mudá-lo); cai para a página do app. */
    private fun openChannelSettings(e: PopupChannels.Entry) {
        val tries = ArrayList<Intent>()
        if (e.channelId.isNotEmpty()) {
            tries.add(
                Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, e.pkg)
                    .putExtra(Settings.EXTRA_CHANNEL_ID, e.channelId)
            )
        }
        tries.add(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, e.pkg))
        tries.add(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + e.pkg)))
        for (i in tries) {
            try {
                startActivity(i)
                return
            } catch (ex: Exception) {
                // Tenta a próxima tela.
            }
        }
        toast("Não foi possível abrir os ajustes deste app.")
    }

    private fun refreshPreview() {
        previewHolder.removeAllViews()
        val icon: Drawable? = try {
            packageManager.getApplicationIcon(packageName)
        } catch (e: Exception) {
            null
        }
        val sample = CardData(
            key = "preview",
            packageName = packageName,
            appName = "App",
            title = "Remetente",
            body = "Prévia do conteúdo da mensagem, em até duas linhas de texto.",
            appIcon = icon,
            avatar = null,
            contentIntent = null,
            postTime = 0L
        )
        val card = NotificationCardView(this)
        card.bind(sample, Prefs.darkCard(this), false)
        previewHolder.addView(
            card,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
    }

    // ---------- Teste ----------

    private fun sendTest() {
        // DESATIVADO: o teste serve para ver a notificação original, sem cartão.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_POST_NOTIFICATIONS)
            return
        }
        postTest()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_POST_NOTIFICATIONS &&
            grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            postTest()
        }
        refresh()
    }

    private fun postTest() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_TEST, "Teste", NotificationManager.IMPORTANCE_HIGH)
        )
        val tap = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val extras = Bundle()
        extras.putBoolean(NotificationService.EXTRA_IS_TEST, true)
        val n = Notification.Builder(this, CHANNEL_TEST)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("Teste do iOS Banners")
            .setContentText("Notificação de teste enviada pelo próprio app.")
            .setContentIntent(tap)
            .setAutoCancel(true)
            // Id fixo (1001) atualiza a mesma notificação; some sozinha se ninguém a remover.
            .setTimeoutAfter(30_000L)
            .addExtras(extras)
            .build()
        nm.notify(1001, n)
        toast(
            if (Prefs.notificationMode(this) == NotificationMode.SAMSUNG) {
                "Teste enviado. DESATIVADO: aparece só a notificação original."
            } else {
                "Teste enviado. Mantenha o celular desbloqueado."
            }
        )
    }

    // ---------- Diagnóstico ----------

    private fun listenerGranted(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        return nm.isNotificationListenerAccessGranted(ComponentName(this, NotificationService::class.java))
    }

    private fun yn(v: Boolean): String = if (v) "sim" else "não"

    private fun oneUiVersion(): String? {
        return try {
            val f = Build.VERSION::class.java.getDeclaredField("SEM_PLATFORM_INT")
            val v = f.getInt(null)
            if (v < 90000) {
                null
            } else {
                val d = v - 90000
                "${d / 10000}.${(d % 10000) / 100}"
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun aodState(): String {
        return try {
            when (Settings.System.getString(contentResolver, "aod_mode")) {
                null -> "não detectado"
                "1" -> "ativado"
                else -> "desativado"
            }
        } catch (e: Exception) {
            "não detectado"
        }
    }

    private fun diagnostics(): String {
        val sb = StringBuilder()
        fun line(k: String, v: String) {
            sb.append(k).append(": ").append(v).append('\n')
        }
        val isA54 = Build.MODEL.startsWith("SM-A546")
        line(
            "Aparelho",
            "${Build.MANUFACTURER} ${Build.MODEL}" + if (isA54) " (Galaxy A54 5G)" else " (não é o A54 5G)"
        )
        line("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        line("One UI", oneUiVersion() ?: "não detectada")
        line("Acesso às notificações", yn(listenerGranted()))
        line("Serviço conectado", yn(NotificationService.connected))
        line("Exibir sobre outros apps", yn(Settings.canDrawOverlays(this)))
        line(
            "Substituir notificações nativas",
            Prefs.notificationMode(this).label
        )
        line("Cartão iOS ativo agora", yn(controller.status().presenting))
        line("Permissão WRITE_SECURE_SETTINGS (só restaura)", yn(SystemPopups.hasPermission(this)))
        line("Pop-ups do sistema desligados", yn(SystemPopups.disabled(this)))
        if (Build.VERSION.SDK_INT >= 33) {
            line(
                "Notificações do app (teste)",
                yn(checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
            )
        }
        val pm = getSystemService(PowerManager::class.java)
        line("Sem restrição de bateria", yn(pm.isIgnoringBatteryOptimizations(packageName)))
        val wm = getSystemService(WindowManager::class.java)
        val blur = Build.VERSION.SDK_INT >= 31 && wm.isCrossWindowBlurEnabled
        line("Desfoque do sistema", yn(blur))
        line("AOD do sistema (leitura aprox.)", aodState())
        line("Integração com o AOD", "não suportada")
        return sb.toString().trimEnd()
    }

    // ---------- Helpers de interface ----------

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setColor(color)
        return g
    }

    /** Crédito do desenvolvedor: alto contraste (branco sobre fundo escuro) e destacado por borda azul. */
    private fun creditBadge(parent: LinearLayout) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        val bg = rounded(CARD_BG, 16)
        bg.setStroke(dp(2), ACCENT)
        box.background = bg
        box.setPadding(dp(16), dp(12), dp(16), dp(12))
        text(box, "Desenvolvido por", 13f, TEXT_2).gravity = Gravity.CENTER
        text(box, CREDIT_HANDLE, 22f, Color.WHITE, bold = true).gravity = Gravity.CENTER
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(16)
        parent.addView(box, lp)
    }

    private fun section(parent: LinearLayout, title: String): LinearLayout {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = rounded(CARD_BG, 18)
        card.setPadding(dp(16), dp(14), dp(16), dp(16))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        parent.addView(card, lp)
        text(card, title, 17f, Color.WHITE, bold = true).setPadding(0, 0, 0, dp(8))
        return card
    }

    private fun text(
        parent: LinearLayout,
        value: String,
        sp: Float,
        color: Int,
        bold: Boolean = false
    ): TextView {
        val t = TextView(this)
        t.text = value
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (bold) t.paint.isFakeBoldText = true
        parent.addView(
            t,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        return t
    }

    private fun button(parent: LinearLayout, label: String, primary: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.background = rounded(if (primary) ACCENT else GRAY_BTN, 12)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
        lp.topMargin = dp(8)
        parent.addView(b, lp)
        return b
    }

    /** Chave com polegar branco e trilho sempre visível (azul ligado, cinza desligado), em qualquer tema. */
    private fun styleSwitch(sw: Switch) {
        fun pill(color: Int): GradientDrawable {
            val d = GradientDrawable()
            d.shape = GradientDrawable.RECTANGLE
            d.cornerRadius = dp(13).toFloat()
            d.setColor(color)
            d.setSize(dp(46), dp(26))
            return d
        }
        val track = StateListDrawable()
        track.addState(intArrayOf(android.R.attr.state_checked), pill(ACCENT))
        track.addState(intArrayOf(), pill(Color.rgb(142, 142, 147)))
        val thumb = GradientDrawable()
        thumb.shape = GradientDrawable.OVAL
        thumb.setColor(Color.WHITE)
        thumb.setSize(dp(22), dp(22))
        sw.trackDrawable = track
        sw.thumbDrawable = thumb
    }

    private fun switchRow(
        parent: LinearLayout,
        label: String,
        hint: String?,
        onChange: (Boolean) -> Unit
    ): Switch {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.setPadding(0, dp(6), 0, dp(6))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(this)
        t.text = label
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
        t.setTextColor(Color.WHITE)
        row.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        styleSwitch(sw)
        sw.setOnCheckedChangeListener { _, isChecked -> if (!binding) onChange(isChecked) }
        row.addView(sw)
        wrap.addView(row)
        if (hint != null) {
            val h = TextView(this)
            h.text = hint
            h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            h.setTextColor(TEXT_2)
            wrap.addView(h)
        }
        parent.addView(
            wrap,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        return sw
    }
}
