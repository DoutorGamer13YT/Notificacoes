package app.iosbanners

import java.util.concurrent.ConcurrentHashMap

/**
 * Controle de repetição e duplicidade do NotificationService (extraído dele sem mudar as regras):
 * quais notificações já viraram cartão, quais originais nós mesmos removemos e qual evento é novo.
 * Não guarda texto nem conteúdo: só chaves do sistema, hashes e horários.
 *
 * É acessado pela thread principal e pela thread de trabalho do serviço; por isso só usa coleções
 * concorrentes. Sem nenhuma classe do Android: testado na JVM (CardLedgerTest).
 */
class CardLedger(private val maxEntries: Int = 300) {

    /** Hash do último evento tratado de cada chave (evita repetir o cartão da mesma atualização). */
    private val lastHash = ConcurrentHashMap<String, Int>()

    /** Chaves que nós mesmos removemos (para não repetir o cartão se o app republicar igual). */
    private val removedByUs: MutableSet<String> = ConcurrentHashMap.newKeySet()

    /** Chaves da notificação de teste: ela sempre sai depois do cartão. */
    private val testKeys: MutableSet<String> = ConcurrentHashMap.newKeySet()

    /**
     * Chaves cujo cartão do evento atual já apareceu e cuja original já foi removida por nós.
     * Se o app republicar o mesmo evento, a original volta e é removida de novo, em silêncio.
     */
    private val cardedKeys: MutableSet<String> = ConcurrentHashMap.newKeySet()

    /** "When" da notificação que originou o cartão atual de cada chave. */
    private val lastWhen = ConcurrentHashMap<String, Long>()

    /** Mesma chave e mesmo "when" de um evento que já virou cartão: o app só republicou a original. */
    fun isRepublishOfCarded(key: String, whenMs: Long?): Boolean =
        cardedKeys.contains(key) && lastWhen[key] == whenMs

    /** O evento (conteúdo) é igual ao último tratado para esta chave? */
    fun isSameEvent(key: String, hash: Int): Boolean = lastHash[key] == hash

    fun isCarded(key: String): Boolean = cardedKeys.contains(key)

    /** Registra um evento novo: ainda não há cartão confirmado para ele. */
    fun startEvent(key: String, hash: Int, whenMs: Long) {
        if (lastHash.size > maxEntries) {
            lastHash.clear()
            cardedKeys.clear()
            lastWhen.clear()
        }
        lastHash[key] = hash
        cardedKeys.remove(key)
        lastWhen[key] = whenMs
    }

    /**
     * O sistema avisou que a notificação saiu. Se fomos nós que a removemos, mantém o estado (evita
     * repetir o cartão se o app republicar igual). Se foi o app ou o usuário, o próximo post com
     * esta chave é um evento novo.
     *
     * @return true se a remoção foi nossa; false se foi o app de origem, o usuário ou o sistema
     *   (nesse caso um cartão desta chave ainda na tela já não tem mais o que mostrar).
     */
    fun onRemoved(key: String): Boolean {
        if (removedByUs.remove(key)) return true
        lastHash.remove(key)
        cardedKeys.remove(key)
        lastWhen.remove(key)
        return false
    }

    /** Vamos remover a original desta chave agora. */
    fun markRemovedByUs(key: String) {
        if (removedByUs.size > 100) removedByUs.clear()
        removedByUs.add(key)
        cardedKeys.add(key)
    }

    /** A remoção falhou: desfaz a marca. */
    fun unmarkRemovedByUs(key: String) {
        removedByUs.remove(key)
        cardedKeys.remove(key)
    }

    fun markTest(key: String) {
        if (testKeys.size > 20) testKeys.clear()
        testKeys.add(key)
    }

    /** true se a chave era da notificação de teste (e a esquece). */
    fun consumeTest(key: String): Boolean = testKeys.remove(key)

    /**
     * Esquece tudo. Chamado ao trocar de modo: sem isso, uma notificação que ficou na central
     * durante o modo Samsung poderia ser tratada como "já virou cartão" ao voltar para o iOS e ser
     * removida sem cartão nenhum (notificação perdida).
     */
    fun clear() {
        lastHash.clear()
        removedByUs.clear()
        testKeys.clear()
        cardedKeys.clear()
        lastWhen.clear()
    }
}
