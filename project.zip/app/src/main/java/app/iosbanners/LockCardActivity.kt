package app.iosbanners

import android.app.Activity
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import java.lang.ref.WeakReference

/**
 * EXPERIMENTAL. Usado quando a notificação chega com a tela apagada ou bloqueada: acende a tela bem fraca,
 * sem barras do sistema, com fundo preto puro e só o cartão. Em tela AMOLED o preto fica apagado,
 * então visualmente sobra só a notificação.
 *
 * Isso NÃO é o Always On Display: a tela fica realmente ligada (Activity com setShowWhenLocked +
 * setTurnScreenOn) até o tempo limite de tela do sistema, ou até o limite de segurança abaixo.
 * A posição do cartão é a MESMA do banner da tela ligada ([bannerTopOffset]), sem variação.
 * Como a tela fica fraca e por poucos segundos, o risco de burn-in é desprezível.
 */
class LockCardActivity : Activity() {

    companion object {
        private const val BRIGHTNESS = 0.2f
        // Tela ligada é o maior gasto de bateria deste recurso; 12 s bastam para ler o cartão.
        private const val MAX_VISIBLE_MS = 12000L

        // A tela leva um instante para acender. A original sai assim que a janela ganha foco com a
        // tela acesa (veja onWindowFocusChanged); este prazo é só a garantia caso o foco não chegue.
        private const val REMOVE_ORIGINAL_FALLBACK_MS = 700L

        /** A tela aberta agora (no máximo uma, mesmo processo). Referência fraca: não vaza a Activity. */
        @Volatile
        private var current: WeakReference<LockCardActivity>? = null

        /**
         * Fecha o cartão da tela bloqueada, se estiver aberto (troca para o modo Samsung). Também
         * descarta o cartão pendente. Pode ser chamado de qualquer thread. Não apaga notificação nenhuma.
         */
        fun closeIfOpen() {
            CardStore.pending = null
            val a = current?.get() ?: return
            a.runOnUiThread { if (!a.isFinishing) a.finish() }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val finishRunnable = Runnable { finish() }

    /** Com o aparelho desbloqueado (biometria etc.) o cartão não tem mais o que fazer na frente. */
    private val userPresentReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            // Se foi o toque no cartão que pediu o desbloqueio, quem encerra é o callback dele,
            // depois de abrir o app de origem.
            if (!unlocking) finish()
        }
    }
    private var receiverRegistered = false

    /** True enquanto o toque no cartão aguarda o desbloqueio para abrir o app de origem. */
    private var unlocking = false

    /** Original aguardando a confirmação de que o cartão está visível (só a do cartão atual). */
    private val pendingOriginalKeys = LinkedHashSet<String>()
    private val removeOriginalRunnable = Runnable {
        val pm = getSystemService(PowerManager::class.java)
        // Se a tela ainda não acendeu, a original fica: nunca remover sem o cartão estar visível.
        if (!isFinishing && pm?.isInteractive == true) {
            for (key in pendingOriginalKeys) NotificationService.removeOriginalIfEnabled(key)
            pendingOriginalKeys.clear()
        }
    }
    private lateinit var root: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = WeakReference(this)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        registerReceiver(userPresentReceiver, IntentFilter(Intent.ACTION_USER_PRESENT))
        receiverRegistered = true

        val attrs = window.attributes
        attrs.screenBrightness = BRIGHTNESS
        // A janela sempre começa no topo físico da tela (mesmo com recorte/furo da câmera e
        // barras ocultas), para o cartão ficar na mesma posição do banner da tela ligada.
        attrs.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = attrs

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        // Toque fora do cartão: fecha e volta ao bloqueio.
        root.setOnClickListener { finish() }
        setContentView(root)
        hideSystemBars()
        render(CardStore.pending)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        render(CardStore.pending)
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            val c = window.insetsController
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars())
                c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
    }

    private fun render(data: CardData?) {
        if (data == null) {
            finish()
            return
        }
        root.removeAllViews()
        val card = NotificationCardView(this)
        card.bind(data, Prefs.darkCard(this), false)
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        // Mesmo alinhamento superior do banner da tela ligada (margem lateral de 8dp igual).
        lp.setMargins(dp(8), bannerTopOffset(), dp(8), 0)
        root.addView(card, lp)

        card.alpha = 0f
        card.translationY = -dp(30).toFloat()
        card.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(380)
            .setInterpolator(PathInterpolator(0.2f, 0.9f, 0.2f, 1f))
            .start()

        card.setOnClickListener { openAfterUnlock(data) }

        // Só depois que o cartão está na tela e a tela realmente acesa, remove a original
        // (evita duplicar sem correr o risco de ficar sem nenhuma das duas). Se este cartão
        // substituiu outro que ainda não tinha sido confirmado, a original do anterior fica na
        // central de notificações em vez de sumir sem ter sido vista.
        pendingOriginalKeys.clear()
        // Notificações que não podem ser removidas (lembretes, "não dispensáveis"...) ficam na central.
        if (data.cancelAllowed) pendingOriginalKeys.add(data.key)
        handler.removeCallbacks(removeOriginalRunnable)
        if (hasWindowFocus()) {
            // Janela já visível (atualização do cartão): não há o que esperar.
            handler.post(removeOriginalRunnable)
        } else {
            handler.postDelayed(removeOriginalRunnable, REMOVE_ORIGINAL_FALLBACK_MS)
        }

        handler.removeCallbacks(finishRunnable)
        handler.postDelayed(finishRunnable, MAX_VISIBLE_MS)
    }

    private fun openAfterUnlock(data: CardData) {
        handler.removeCallbacks(finishRunnable)
        val km = getSystemService(KeyguardManager::class.java)
        if (km == null) {
            finish()
            return
        }
        unlocking = true
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() {
                openSource(applicationContext, data)
                finish()
            }

            override fun onDismissCancelled() {
                finish()
            }

            override fun onDismissError() {
                finish()
            }
        })
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Janela visível e com foco: remove a original já, sem esperar o prazo de garantia
        // (que continua agendado e só age se isto ainda não tiver acontecido).
        if (hasFocus && pendingOriginalKeys.isNotEmpty()) handler.post(removeOriginalRunnable)
    }

    override fun onStop() {
        super.onStop()
        // Quando a tela apaga pelo tempo limite do sistema (ou outro app abre), encerra o cartão.
        if (!isFinishing) finish()
    }

    override fun onDestroy() {
        handler.removeCallbacks(finishRunnable)
        handler.removeCallbacks(removeOriginalRunnable)
        if (current?.get() === this) current = null
        if (receiverRegistered) {
            receiverRegistered = false
            try {
                unregisterReceiver(userPresentReceiver)
            } catch (e: IllegalArgumentException) {
                // Já removido.
            }
        }
        super.onDestroy()
    }
}
