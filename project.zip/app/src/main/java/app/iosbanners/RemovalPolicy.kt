package app.iosbanners

/**
 * Decide se a notificação ORIGINAL pode ser dispensada depois que o cartão estilo iOS apareceu.
 * Lógica pura (sem Android), usada por NotificationService e coberta por testes unitários.
 *
 * Só se chega aqui para notificações que já viraram cartão: chamadas, alarmes, navegação, avisos de
 * tela cheia, mídia, progresso, serviços em primeiro plano e resumos de grupo são descartados antes
 * (em NotificationService.handle) e nunca são removidos.
 */
object RemovalPolicy {

    /**
     * @param customActive apresentação personalizada ligada (modo iOS + recurso ligado).
     * @param isTestKey a notificação é a de teste do próprio app (sempre sai, para não sobrar na central).
     * @param exclusiveMode opção "Modo de notificação exclusiva".
     * @param originalWouldPopUp só é consultada se for necessária (lê o ranking do sistema).
     */
    fun shouldRemove(
        customActive: Boolean,
        isTestKey: Boolean,
        exclusiveMode: Boolean,
        originalWouldPopUp: () -> Boolean
    ): Boolean {
        // Modo Samsung (ou recurso desligado): este app não remove NADA.
        if (!customActive) return false
        if (isTestKey) return true
        if (!exclusiveMode) return false
        // Canal sem pop-up: a original fica na central (som, respostas rápidas) e não há duplicidade.
        return originalWouldPopUp()
    }
}
