package app.iosbanners

/**
 * Dados de uma notificação já lidos do Android (sem nenhuma classe do Android: testável na JVM).
 * Quem preenche é NotificationService.traitsOf.
 */
data class NotificationTraits(
    val isOwnPackage: Boolean = false,
    /** A notificação de teste que o próprio app envia (botão "Enviar notificação de teste"). */
    val isOwnTest: Boolean = false,
    val isGroupSummary: Boolean = false,
    val isOngoing: Boolean = false,
    val isForegroundService: Boolean = false,
    /** FLAG_NO_CLEAR: o app de origem não quer que ela seja dispensada. */
    val isNoClear: Boolean = false,
    /** FLAG_INSISTENT: som repetido até o usuário agir (alarmes e chamadas). */
    val isInsistent: Boolean = false,
    val hasFullScreenIntent: Boolean = false,
    val isBubble: Boolean = false,
    val isProgress: Boolean = false,
    /** Tem sessão de mídia (controles de reprodução). */
    val hasMediaSession: Boolean = false,
    val category: String? = null,
    /** Notification.EXTRA_TEMPLATE (ex.: "android.app.Notification$MediaStyle"). */
    val template: String? = null
)

/** O que fazer com uma notificação. */
enum class Treatment {
    /** Não tocar: nem cartão, nem remoção. A notificação fica como o sistema a mostra. */
    IGNORE,

    /** Mostra o cartão, mas a original continua na central (nunca é removida por este app). */
    BANNER_ONLY,

    /** Mostra o cartão e a original pode ser dispensada (ainda sujeita a RemovalPolicy). */
    BANNER_AND_REPLACE
}

data class Decision(val treatment: Treatment, val reason: String) {
    val showsBanner: Boolean get() = treatment != Treatment.IGNORE
    val mayCancelOriginal: Boolean get() = treatment == Treatment.BANNER_AND_REPLACE
}

/**
 * Regras do que pode ser trocado e do que pode ser removido. Lógica pura, coberta por testes.
 *
 * Princípio: só se remove a original de uma notificação comum de aviso/mensagem. Chamadas, alarmes,
 * navegação, mídia, serviços em primeiro plano, progresso, avisos de tela cheia e tudo o que o app
 * de origem marcou como "não dispensável" ficam intocados.
 */
object NotificationPolicy {

    // Valores idênticos aos de Notification.CATEGORY_* (um teste confere cada um contra o SDK).
    const val CAT_CALL = "call"
    const val CAT_MISSED_CALL = "missed_call"
    const val CAT_ALARM = "alarm"
    const val CAT_NAVIGATION = "navigation"
    const val CAT_TRANSPORT = "transport"
    const val CAT_PROGRESS = "progress"
    const val CAT_SERVICE = "service"
    const val CAT_SYSTEM = "sys"
    const val CAT_STATUS = "status"
    const val CAT_STOPWATCH = "stopwatch"
    const val CAT_LOCATION_SHARING = "location_sharing"
    const val CAT_WORKOUT = "workout"
    const val CAT_REMINDER = "reminder"
    const val CAT_EVENT = "event"

    /** Nunca trocadas nem removidas. */
    private val UNTOUCHABLE_CATEGORIES: Set<String> = setOf(
        CAT_CALL, CAT_MISSED_CALL, CAT_ALARM, CAT_NAVIGATION, CAT_TRANSPORT, CAT_PROGRESS,
        CAT_SERVICE, CAT_SYSTEM, CAT_STATUS, CAT_STOPWATCH, CAT_LOCATION_SHARING, CAT_WORKOUT
    )

    /** Podem virar cartão, mas a original fica (lembretes e eventos: o usuário precisa agir sobre eles). */
    private val KEEP_ORIGINAL_CATEGORIES: Set<String> = setOf(CAT_REMINDER, CAT_EVENT)

    fun evaluate(t: NotificationTraits): Decision {
        if (t.isOwnPackage) {
            // Do próprio app, só a notificação de teste passa (e ela sempre sai depois do cartão).
            return if (t.isOwnTest) {
                Decision(Treatment.BANNER_AND_REPLACE, "teste do próprio app")
            } else {
                Decision(Treatment.IGNORE, "notificação do próprio app")
            }
        }
        if (t.isGroupSummary) return ignore("resumo de grupo")
        if (t.isOngoing || t.isForegroundService) return ignore("em andamento / serviço em primeiro plano")
        if (isMedia(t)) return ignore("mídia")
        if (isCall(t)) return ignore("chamada")
        val category = t.category
        if (category != null && category in UNTOUCHABLE_CATEGORIES) return ignore("categoria protegida: $category")
        if (t.hasFullScreenIntent) return ignore("aviso de tela cheia")
        if (t.isProgress) return ignore("progresso")

        if (t.isNoClear) return Decision(Treatment.BANNER_ONLY, "o app marcou como não dispensável")
        if (t.isInsistent) return Decision(Treatment.BANNER_ONLY, "som insistente")
        if (t.isBubble) return Decision(Treatment.BANNER_ONLY, "bolha de conversa")
        if (category != null && category in KEEP_ORIGINAL_CATEGORIES) {
            return Decision(Treatment.BANNER_ONLY, "lembrete/evento fica na central")
        }
        return Decision(Treatment.BANNER_AND_REPLACE, "notificação comum")
    }

    private fun ignore(reason: String) = Decision(Treatment.IGNORE, reason)

    private fun isMedia(t: NotificationTraits): Boolean {
        if (t.hasMediaSession || t.category == CAT_TRANSPORT) return true
        val template = t.template ?: return false
        // MediaStyle e DecoratedMediaCustomViewStyle.
        return template.contains("MediaStyle") || template.contains("MediaCustomViewStyle")
    }

    private fun isCall(t: NotificationTraits): Boolean {
        if (t.category == CAT_CALL) return true
        val template = t.template ?: return false
        return template.endsWith("CallStyle")
    }
}

/** Uma ação (botão) de uma notificação, já reduzida ao que a seleção precisa saber. */
data class ActionInfo(val title: String?, val hasIntent: Boolean, val acceptsText: Boolean)

/**
 * Quais ações da notificação original o cartão reapresenta. O cartão não tem campo de texto, então
 * ações de resposta (RemoteInput) ficam de fora: para responder, toque no cartão (abre o app de
 * origem). Ações sem título ou sem intenção também ficam de fora.
 */
object ActionPolicy {
    const val MAX_ACTIONS = 3

    /** Índices (na lista original) das ações que viram botão, na mesma ordem. */
    fun select(actions: List<ActionInfo>): List<Int> {
        val picked = ArrayList<Int>()
        for ((i, a) in actions.withIndex()) {
            if (picked.size >= MAX_ACTIONS) break
            if (a.title.isNullOrBlank() || !a.hasIntent || a.acceptsText) continue
            picked.add(i)
        }
        return picked
    }
}
