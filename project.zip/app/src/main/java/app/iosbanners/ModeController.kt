package app.iosbanners

/**
 * Tudo que o ModeController precisa do mundo exterior. A implementação real é a
 * AndroidModeEnvironment; os testes usam uma versão em memória.
 */
interface ModeEnvironment {
    fun mode(): NotificationMode

    /** Grava a escolha de forma síncrona. false = não foi possível gravar. */
    fun saveMode(mode: NotificationMode): Boolean

    /** Chave "Ativar banners estilo iOS". */
    fun masterEnabled(): Boolean
    fun setMasterEnabled(value: Boolean)

    fun listenerGranted(): Boolean
    fun overlayGranted(): Boolean

    /** WRITE_SECURE_SETTINGS (só por adb). */
    fun popupsPermissionGranted(): Boolean
    fun popupsDisabledInSystem(): Boolean
    fun setPopupsDisabledInSystem(disabled: Boolean): Boolean

    /** Foi este app que desligou o pop-up do sistema (e por isso cabe a ele restaurar)? */
    fun popupsOwnedByApp(): Boolean
    fun setPopupsOwnedByApp(value: Boolean)

    /** O usuário ligou a opção avançada "desligar pop-ups do sistema" e não a desfez. */
    fun popupsWanted(): Boolean
    fun setPopupsWanted(value: Boolean)

    /** Fecha o cartão que estiver na tela, descarta trabalho pendente e esquece o estado de deduplicação. */
    fun resetPresentation()
}

/** Resultado de ligar/desligar o ajuste avançado de pop-ups do sistema. */
enum class PopupsOutcome { DONE, NEEDS_PERMISSION, BLOCKED_BY_SAMSUNG_MODE, FAILED }

/**
 * Lógica da troca entre modo iOS e modo Samsung. Sem Android: testada na JVM.
 *
 * Regras:
 * - A escolha é gravada primeiro e de forma síncrona; se falhar, nada mais muda.
 * - Samsung: fecha o cartão, esquece o estado interno e restaura o ajuste de pop-ups do sistema
 *   somente se FOI ESTE APP que o alterou. Nunca apaga notificações.
 * - iOS: liga o recurso, começa com estado limpo e, se o usuário tinha ligado a opção avançada de
 *   pop-ups, desliga o ajuste de novo.
 * - Faltando permissão, a escolha continua salva, mas o estado diz o que falta (e nada é removido).
 */
class ModeController(private val env: ModeEnvironment) {

    /**
     * @param ok a escolha foi gravada e o modo mudou.
     * @param notes avisos para mostrar ao usuário.
     * @param missing o que falta para o modo iOS funcionar (vazio no modo Samsung).
     * @param popupsRestorePending o app alterou o pop-up do sistema e não conseguiu restaurar agora.
     */
    data class Result(
        val ok: Boolean,
        val mode: NotificationMode,
        val notes: List<String>,
        val missing: List<Requirement>,
        val popupsRestorePending: Boolean = false
    )

    companion object {
        const val MSG_SAVE_FAILED =
            "Não foi possível salvar a escolha. O modo anterior continua ativo."
        const val MSG_RESET_FAILED =
            "Não consegui fechar o cartão que estava na tela; ele some sozinho em instantes."
        const val MSG_PARTIAL = "A troca foi salva, mas parte dela falhou: "
        const val MSG_POPUPS_RESTORED = "Pop-ups do sistema restaurados."
        const val MSG_POPUPS_REAPPLIED =
            "Pop-ups do sistema desligados de novo (opção avançada que você tinha ligado)."
        const val MSG_POPUPS_RESTORE_FAILED =
            "Não consegui restaurar os pop-ups do sistema (falta a permissão WRITE_SECURE_SETTINGS). " +
                "Para restaurar à mão: adb shell settings put global " + SystemPopups.KEY + " 1"
        const val MSG_POPUPS_REAPPLY_FAILED =
            "Não consegui desligar os pop-ups do sistema de novo (falta a permissão WRITE_SECURE_SETTINGS)."
    }

    fun status(): ModeStatus =
        ModeStatus.of(env.mode(), env.masterEnabled(), env.listenerGranted(), env.overlayGranted())

    /** Troca de modo, aplicada na hora. Seguro para repetir (idempotente). */
    fun select(target: NotificationMode): Result {
        val previous = env.mode()
        val saved = try {
            env.saveMode(target)
        } catch (e: Exception) {
            false
        }
        if (!saved) return Result(false, previous, listOf(MSG_SAVE_FAILED), emptyList())

        val notes = ArrayList<String>()
        var pending = false
        try {
            if (target == NotificationMode.SAMSUNG) {
                resetPresentation(notes)
                pending = restorePopupsIfOwned(notes)
            } else {
                if (!env.masterEnabled()) env.setMasterEnabled(true)
                resetPresentation(notes)
                reapplyPopupsIfWanted(notes)
            }
        } catch (e: Exception) {
            notes.add(MSG_PARTIAL + (e.message ?: e.javaClass.simpleName))
        }
        return Result(true, target, notes, status().missing, pending)
    }

    /**
     * Reaplica o modo salvo depois de reiniciar o aparelho ou reconectar o serviço. A escolha em si
     * já está gravada; aqui só se corrige o que ficou pelo meio (por exemplo, o app foi encerrado no
     * meio de uma troca). Idempotente.
     */
    fun reconcile(): Result {
        val notes = ArrayList<String>()
        var pending = false
        try {
            if (env.mode() == NotificationMode.SAMSUNG) {
                pending = restorePopupsIfOwned(notes)
            } else if (env.popupsOwnedByApp() && !env.popupsDisabledInSystem()) {
                // Alguém restaurou o pop-up por fora (por exemplo, por adb): respeita e deixa de
                // considerá-lo nosso, em vez de desligar de novo toda vez.
                env.setPopupsOwnedByApp(false)
                env.setPopupsWanted(false)
            }
        } catch (e: Exception) {
            notes.add(MSG_PARTIAL + (e.message ?: e.javaClass.simpleName))
        }
        return Result(true, env.mode(), notes, status().missing, pending)
    }

    /** Botão avançado "desligar/restaurar os pop-ups do sistema". */
    fun setSystemPopupsDisabled(disabled: Boolean): PopupsOutcome {
        if (disabled) {
            // No modo Samsung os pop-ups nativos ficam como estão.
            if (env.mode() == NotificationMode.SAMSUNG) return PopupsOutcome.BLOCKED_BY_SAMSUNG_MODE
            if (!env.popupsPermissionGranted()) return PopupsOutcome.NEEDS_PERMISSION
            if (!env.setPopupsDisabledInSystem(true)) return PopupsOutcome.FAILED
            env.setPopupsOwnedByApp(true)
            env.setPopupsWanted(true)
            return PopupsOutcome.DONE
        }
        // Restaurar. Se já está restaurado, só acerta os registros do app.
        if (env.popupsDisabledInSystem()) {
            if (!env.popupsPermissionGranted()) return PopupsOutcome.NEEDS_PERMISSION
            if (!env.setPopupsDisabledInSystem(false)) return PopupsOutcome.FAILED
        }
        env.setPopupsOwnedByApp(false)
        env.setPopupsWanted(false)
        return PopupsOutcome.DONE
    }

    private fun resetPresentation(notes: MutableList<String>) {
        try {
            env.resetPresentation()
        } catch (e: Exception) {
            notes.add(MSG_RESET_FAILED)
        }
    }

    /** Devolve true se ainda falta restaurar (não deu para escrever o ajuste agora). */
    private fun restorePopupsIfOwned(notes: MutableList<String>): Boolean {
        if (!env.popupsOwnedByApp()) return false
        if (!env.popupsDisabledInSystem()) {
            // Já está restaurado (por nós ou por fora): só limpa o registro.
            env.setPopupsOwnedByApp(false)
            return false
        }
        val done = env.popupsPermissionGranted() && env.setPopupsDisabledInSystem(false)
        if (done) {
            env.setPopupsOwnedByApp(false)
            notes.add(MSG_POPUPS_RESTORED)
            return false
        }
        notes.add(MSG_POPUPS_RESTORE_FAILED)
        return true
    }

    private fun reapplyPopupsIfWanted(notes: MutableList<String>) {
        if (!env.popupsWanted()) return
        // Se o ajuste já está desligado, foi por fora: não é nosso, não mexe.
        if (env.popupsDisabledInSystem()) return
        if (env.popupsPermissionGranted() && env.setPopupsDisabledInSystem(true)) {
            env.setPopupsOwnedByApp(true)
            notes.add(MSG_POPUPS_REAPPLIED)
        } else {
            notes.add(MSG_POPUPS_REAPPLY_FAILED)
        }
    }
}
