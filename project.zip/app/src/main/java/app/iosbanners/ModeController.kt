package app.iosbanners

/**
 * Tudo que o ModeController precisa do mundo exterior. A implementação real é a
 * AndroidModeEnvironment; os testes usam uma versão em memória.
 */
interface ModeEnvironment {
    fun mode(): NotificationMode

    /** Grava a escolha de forma síncrona. false = não foi possível gravar. */
    fun saveMode(mode: NotificationMode): Boolean

    fun listenerGranted(): Boolean
    fun overlayGranted(): Boolean

    /** WRITE_SECURE_SETTINGS (só por adb). Só é verificada; serve apenas para restaurar (abaixo). */
    fun popupsPermissionGranted(): Boolean

    /** O ajuste global de pop-ups do sistema está desligado agora? (só leitura) */
    fun popupsDisabledInSystem(): Boolean

    /** Religa o ajuste global de pop-ups do sistema. false = o sistema recusou (falta a permissão). */
    fun restoreSystemPopups(): Boolean

    /**
     * Uma versão anterior DESTE app desligou o ajuste global de pop-ups (e por isso cabe a ele
     * restaurar)? Esta versão nunca desliga; o registro só existe por causa de instalações antigas.
     */
    fun popupsOwnedByApp(): Boolean
    fun setPopupsOwnedByApp(value: Boolean)

    /** Fecha o cartão que estiver na tela, descarta trabalho pendente e esquece o estado de deduplicação. */
    fun resetPresentation()
}

/** Resultado do botão "Restaurar os pop-ups do sistema". */
enum class PopupsOutcome { DONE, NEEDS_PERMISSION, FAILED }

/**
 * Lógica da troca entre ATIVADO e DESATIVADO. Sem Android: testada na JVM.
 *
 * Regras:
 * - A escolha é gravada primeiro e de forma síncrona; se falhar, nada mais muda.
 * - Nos dois sentidos: fecha o cartão, esquece o estado interno e, se uma versão anterior deste app
 *   desligou o ajuste global de pop-ups, restaura (somente se FOI ESTE APP que o alterou).
 * - NENHUM modo desliga pop-ups, notificações ou canais de outros apps: este controlador não escreve
 *   no sistema, só restaura. Também nunca apaga notificações.
 * - Faltando permissão, a escolha continua salva, mas o estado diz o que falta (e nada é removido).
 */
class ModeController(private val env: ModeEnvironment) {

    /**
     * @param ok a escolha foi gravada e o modo mudou.
     * @param notes avisos para mostrar ao usuário.
     * @param missing o que falta para o modo ATIVADO funcionar (vazio no DESATIVADO).
     * @param popupsRestorePending uma versão anterior do app alterou o pop-up do sistema e não deu
     *   para restaurar agora.
     */
    data class Result(
        val ok: Boolean,
        val mode: NotificationMode,
        val notes: List<String>,
        val missing: List<Requirement>,
        val popupsRestorePending: Boolean = false
    )

    companion object {
        const val MSG_SAVE_FAILED =
            "Não foi possível salvar a escolha. O modo anterior continua ativo."
        const val MSG_RESET_FAILED =
            "Não consegui fechar o cartão que estava na tela; ele some sozinho em instantes."
        const val MSG_PARTIAL = "A troca foi salva, mas parte dela falhou: "
        const val MSG_POPUPS_RESTORED = "Pop-ups do sistema restaurados."
        const val MSG_POPUPS_RESTORE_FAILED =
            "Não consegui restaurar os pop-ups do sistema (falta a permissão WRITE_SECURE_SETTINGS). " +
                "Para restaurar à mão: adb shell settings put global " + SYSTEM_POPUPS_SETTING_KEY + " 1"
    }

    fun status(): ModeStatus =
        ModeStatus.of(env.mode(), env.listenerGranted(), env.overlayGranted())

    /** Troca de modo, aplicada na hora. Seguro para repetir (idempotente). */
    fun select(target: NotificationMode): Result {
        val previous = env.mode()
        val saved = try {
            env.saveMode(target)
        } catch (e: Exception) {
            false
        }
        if (!saved) return Result(false, previous, listOf(MSG_SAVE_FAILED), emptyList())

        val notes = ArrayList<String>()
        var pending = false
        try {
            resetPresentation(notes)
            pending = restorePopupsIfOwned(notes)
        } catch (e: Exception) {
            notes.add(MSG_PARTIAL + (e.message ?: e.javaClass.simpleName))
        }
        return Result(true, target, notes, status().missing, pending)
    }

    /**
     * Reaplica o modo salvo depois de reiniciar o aparelho ou reconectar o serviço. A escolha em si
     * já está gravada; aqui só se corrige o que ficou pelo meio (por exemplo, o app foi encerrado no
     * meio de uma troca). Idempotente.
     */
    fun reconcile(): Result {
        val notes = ArrayList<String>()
        var pending = false
        try {
            pending = restorePopupsIfOwned(notes)
        } catch (e: Exception) {
            notes.add(MSG_PARTIAL + (e.message ?: e.javaClass.simpleName))
        }
        return Result(true, env.mode(), notes, status().missing, pending)
    }

    /**
     * Botão "Restaurar os pop-ups do sistema" (só aparece com o ajuste desligado). Iniciado pelo
     * usuário; o app nunca faz o contrário (desligar).
     */
    fun restoreSystemPopups(): PopupsOutcome {
        if (!env.popupsDisabledInSystem()) {
            // Já está ligado: só acerta o registro do app.
            env.setPopupsOwnedByApp(false)
            return PopupsOutcome.DONE
        }
        if (!env.popupsPermissionGranted()) return PopupsOutcome.NEEDS_PERMISSION
        if (!env.restoreSystemPopups()) return PopupsOutcome.FAILED
        env.setPopupsOwnedByApp(false)
        return PopupsOutcome.DONE
    }

    private fun resetPresentation(notes: MutableList<String>) {
        try {
            env.resetPresentation()
        } catch (e: Exception) {
            notes.add(MSG_RESET_FAILED)
        }
    }

    /** Devolve true se ainda falta restaurar (não deu para escrever o ajuste agora). */
    private fun restorePopupsIfOwned(notes: MutableList<String>): Boolean {
        if (!env.popupsOwnedByApp()) return false
        if (!env.popupsDisabledInSystem()) {
            // Já está restaurado (por nós ou por fora): só limpa o registro.
            env.setPopupsOwnedByApp(false)
            return false
        }
        val done = env.popupsPermissionGranted() && env.restoreSystemPopups()
        if (done) {
            env.setPopupsOwnedByApp(false)
            notes.add(MSG_POPUPS_RESTORED)
            return false
        }
        notes.add(MSG_POPUPS_RESTORE_FAILED)
        return true
    }
}
