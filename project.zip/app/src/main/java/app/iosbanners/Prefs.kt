package app.iosbanners

import android.content.Context
import android.content.SharedPreferences

/** Configurações persistentes (SharedPreferences privado do app). */
object Prefs {
    private const val FILE = "ios_banners_prefs"
    private const val K_ENABLED = "enabled"
    private const val K_DARK = "dark_card"
    private const val K_HIDE_ORIGINAL = "hide_original"
    private const val K_BLUR = "blur"
    private const val K_LOCK_CARD = "lock_card"
    private const val K_LOCK_PREVIEW = "lock_preview"
    private const val K_APPS = "monitored_apps"
    private const val K_ALL_APPS = "all_apps"
    private const val K_POPUP_CHANNELS = "popup_channels"
    private const val K_MODE = "notification_mode"
    private const val K_POPUPS_OWNED = "system_popups_owned"
    private const val K_POPUPS_WANTED = "system_popups_wanted"

    /** Apps pré-selecionados na primeira execução. */
    val DEFAULT_APPS: Set<String> = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "com.instagram.android",
        "com.discord"
    )

    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun enabled(c: Context): Boolean = sp(c).getBoolean(K_ENABLED, false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_ENABLED, v).apply()

    /**
     * Modo de notificações (iOS ou Samsung). Sem valor salvo (instalação nova ou versão anterior),
     * vale o padrão iOS: é o comportamento que o app já tinha.
     */
    fun notificationMode(c: Context): NotificationMode =
        NotificationMode.fromId(sp(c).getString(K_MODE, null))

    /**
     * Grava com commit (síncrono): a escolha precisa estar em disco quando a tela diz que foi
     * salva, mesmo que o aparelho reinicie logo depois. false = não gravou.
     */
    fun setNotificationMode(c: Context, mode: NotificationMode): Boolean =
        sp(c).edit().putString(K_MODE, mode.id).commit()

    /** A apresentação personalizada está valendo agora? (recurso ligado E modo iOS) */
    fun customPresentationActive(c: Context): Boolean =
        enabled(c) && notificationMode(c) == NotificationMode.IOS

    /** Foi este app que desligou o pop-up do sistema (cabe a ele restaurar). */
    fun systemPopupsOwned(c: Context): Boolean = sp(c).getBoolean(K_POPUPS_OWNED, false)
    fun setSystemPopupsOwned(c: Context, v: Boolean) {
        sp(c).edit().putBoolean(K_POPUPS_OWNED, v).commit()
    }

    /** O usuário ligou a opção avançada de desligar os pop-ups do sistema e ainda não a desfez. */
    fun systemPopupsWanted(c: Context): Boolean = sp(c).getBoolean(K_POPUPS_WANTED, false)
    fun setSystemPopupsWanted(c: Context, v: Boolean) {
        sp(c).edit().putBoolean(K_POPUPS_WANTED, v).commit()
    }

    fun darkCard(c: Context): Boolean = sp(c).getBoolean(K_DARK, true)
    fun setDarkCard(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_DARK, v).apply()

    /**
     * Modo de notificação exclusiva (ligado por padrão): só o cartão estilo iOS aparece como pop-up.
     * A chave continua "hide_original" para manter a escolha de quem já usava a opção antiga.
     */
    fun exclusiveMode(c: Context): Boolean = sp(c).getBoolean(K_HIDE_ORIGINAL, true)
    fun setExclusiveMode(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_HIDE_ORIGINAL, v).apply()

    /** Canais com pop-up original ativo (veja PopupChannels). Cada item já vem codificado. */
    fun popupChannelsRaw(c: Context): Set<String> =
        sp(c).getStringSet(K_POPUP_CHANNELS, null) ?: emptySet()

    fun setPopupChannelsRaw(c: Context, raw: Set<String>) =
        sp(c).edit().putStringSet(K_POPUP_CHANNELS, HashSet(raw)).apply()

    fun blur(c: Context): Boolean = sp(c).getBoolean(K_BLUR, false)
    fun setBlur(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_BLUR, v).apply()

    fun lockCard(c: Context): Boolean = sp(c).getBoolean(K_LOCK_CARD, true)
    fun setLockCard(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_LOCK_CARD, v).apply()

    /**
     * Prévia da mensagem com o aparelho bloqueado por PIN/padrão/biometria. Desligada por padrão:
     * o app não consegue ler a opção "ocultar conteúdo sensível" do sistema, então o padrão seguro
     * é mostrar só o nome do app e um texto genérico.
     */
    fun lockPreview(c: Context): Boolean = sp(c).getBoolean(K_LOCK_PREVIEW, false)
    fun setLockPreview(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_LOCK_PREVIEW, v).apply()

    /** Pacotes do próprio sistema que nunca são tratados, nem no modo "todos os apps". */
    private val NEVER_PACKAGES: Set<String> = setOf("android", "com.android.systemui")

    /** Ligado por padrão: o cartão aparece para as notificações de qualquer app. */
    fun allApps(c: Context): Boolean = sp(c).getBoolean(K_ALL_APPS, true)
    fun setAllApps(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_ALL_APPS, v).apply()

    /** O app [pkg] deve ter suas notificações tratadas? (todos os apps, ou só os escolhidos) */
    fun isMonitored(c: Context, pkg: String): Boolean {
        if (pkg in NEVER_PACKAGES) return false
        return allApps(c) || pkg in monitoredApps(c)
    }

    /** Cache em memória: evita reler e copiar o conjunto a cada notificação recebida. */
    @Volatile
    private var appsCache: Set<String>? = null

    fun monitoredApps(c: Context): Set<String> {
        appsCache?.let { return it }
        val stored = sp(c).getStringSet(K_APPS, null)
        val result: Set<String> = if (stored == null) DEFAULT_APPS else HashSet(stored)
        appsCache = result
        return result
    }

    fun setMonitoredApps(c: Context, apps: Set<String>) {
        val copy = HashSet(apps)
        sp(c).edit().putStringSet(K_APPS, copy).apply()
        appsCache = copy
    }
}
