package app.iosbanners

import android.content.Context
import android.net.Uri

/**
 * Canais de notificação de OUTROS apps cujo pop-up original ainda está ativo (importância alta).
 *
 * Guarda só o pacote, o id e o nome do canal (nunca o conteúdo das notificações). Serve para o app
 * mostrar ao usuário quais canais precisam de um ajuste nas configurações do sistema: só o usuário
 * pode mudar o canal de outro app, o Android não oferece essa API a um app comum.
 */
object PopupChannels {
    private const val MAX_ENTRIES = 40
    private const val SEP = "|"

    /** [channelId] vazio = conversas (o ajuste fica na página do app, não num canal único). */
    data class Entry(val pkg: String, val channelId: String, val channelName: String)

    private val lock = Any()
    private var cache: LinkedHashMap<String, Entry>? = null

    private fun keyOf(pkg: String, channelId: String): String = pkg + SEP + channelId

    private fun load(c: Context): LinkedHashMap<String, Entry> {
        cache?.let { return it }
        val map = LinkedHashMap<String, Entry>()
        for (raw in Prefs.popupChannelsRaw(c)) {
            val p = raw.split(SEP)
            if (p.size != 3) continue
            val e = Entry(Uri.decode(p[0]), Uri.decode(p[1]), Uri.decode(p[2]))
            map[keyOf(e.pkg, e.channelId)] = e
        }
        cache = map
        return map
    }

    private fun save(c: Context, map: Map<String, Entry>) {
        val raw = HashSet<String>()
        for (e in map.values) {
            raw.add(Uri.encode(e.pkg) + SEP + Uri.encode(e.channelId) + SEP + Uri.encode(e.channelName))
        }
        Prefs.setPopupChannelsRaw(c, raw)
    }

    /** Atualiza o estado de um canal. Só grava em disco quando algo muda. */
    fun update(c: Context, pkg: String, channelId: String, channelName: String, popsUp: Boolean) {
        synchronized(lock) {
            val map = load(c)
            val k = keyOf(pkg, channelId)
            val old = map[k]
            var changed = false
            if (popsUp) {
                val e = Entry(pkg, channelId, channelName)
                if (old != e) {
                    map[k] = e
                    changed = true
                }
                while (map.size > MAX_ENTRIES) {
                    map.remove(map.keys.iterator().next())
                    changed = true
                }
            } else if (old != null) {
                map.remove(k)
                changed = true
            }
            if (changed) save(c, map)
        }
    }

    fun list(c: Context): List<Entry> = synchronized(lock) { ArrayList(load(c).values) }

    fun clear(c: Context) {
        synchronized(lock) {
            load(c).clear()
            save(c, emptyMap())
        }
    }
}
