package app.iosbanners

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

private typealias LLP = LinearLayout.LayoutParams

/**
 * Cartão de notificação inspirado no visual das notificações do iOS (construído em código, sem XML).
 * Observações: a fonte é a do sistema (a SF Pro da Apple é proprietária) e as medidas são aproximadas.
 */
class NotificationCardView(context: Context) : LinearLayout(context) {

    private val avatar = ImageView(context)
    private val badge = ImageView(context)
    private val title = TextView(context)
    private val meta = TextView(context)
    private val body = TextView(context)
    private val actionsRow = LinearLayout(context)

    /** Ações do app de origem que o cartão pode mostrar (vazio = nenhuma). */
    private var actions: List<CardAction> = emptyList()
    private var expanded = false

    /** Chamado quando o usuário toca numa ação mostrada pelo cartão. */
    var onActionClick: ((CardAction) -> Unit)? = null

    val hasActions: Boolean get() = actions.isNotEmpty()
    val isExpanded: Boolean get() = expanded

    init {
        orientation = HORIZONTAL
        gravity = Gravity.TOP
        val pad = context.dp(14)
        setPadding(pad, pad, pad, pad)

        // Coluna esquerda: avatar/ícone (44dp) + selo do app (20dp) quando há foto.
        val box = FrameLayout(context)
        val boxSize = context.dp(44)
        avatar.scaleType = ImageView.ScaleType.CENTER_CROP
        avatar.clipToOutline = true
        box.addView(avatar, FrameLayout.LayoutParams(boxSize, boxSize))
        badge.scaleType = ImageView.ScaleType.CENTER_CROP
        badge.clipToOutline = true
        badge.outlineProvider = roundOutline(context.dp(5).toFloat())
        val badgeSize = context.dp(20)
        val badgeLp = FrameLayout.LayoutParams(badgeSize, badgeSize, Gravity.END or Gravity.BOTTOM)
        badgeLp.setMargins(0, 0, -context.dp(4), -context.dp(4))
        box.addView(badge, badgeLp)
        addView(box, LLP(boxSize, boxSize))

        // Coluna direita: linha título + meta, e corpo.
        val col = LinearLayout(context)
        col.orientation = VERTICAL
        val colLp = LLP(0, LLP.WRAP_CONTENT, 1f)
        colLp.leftMargin = context.dp(12)
        addView(col, colLp)

        val row = LinearLayout(context)
        row.orientation = HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        title.typeface = Typeface.create(Typeface.DEFAULT, 600, false)
        title.setSingleLine(true)
        title.ellipsize = TextUtils.TruncateAt.END
        row.addView(title, LLP(0, LLP.WRAP_CONTENT, 1f))

        meta.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        meta.setSingleLine(true)
        meta.ellipsize = TextUtils.TruncateAt.END
        val metaLp = LLP(LLP.WRAP_CONTENT, LLP.WRAP_CONTENT)
        metaLp.leftMargin = context.dp(8)
        row.addView(meta, metaLp)
        col.addView(row, LLP(LLP.MATCH_PARENT, LLP.WRAP_CONTENT))

        body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        body.maxLines = 2
        body.ellipsize = TextUtils.TruncateAt.END
        val bodyLp = LLP(LLP.MATCH_PARENT, LLP.WRAP_CONTENT)
        bodyLp.topMargin = context.dp(1)
        col.addView(body, bodyLp)

        // Ações do app de origem (ex.: "Marcar como lida"): só aparecem depois de expandir o cartão.
        actionsRow.orientation = HORIZONTAL
        actionsRow.visibility = View.GONE
        val actionsLp = LLP(LLP.MATCH_PARENT, LLP.WRAP_CONTENT)
        actionsLp.topMargin = context.dp(10)
        col.addView(actionsRow, actionsLp)
    }

    /** Mostra as ações (se houver). O estado expandido é mantido quando o cartão é atualizado no lugar. */
    fun expand() {
        if (actions.isEmpty()) return
        expanded = true
        actionsRow.visibility = View.VISIBLE
    }

    private fun rebuildActions(dark: Boolean) {
        actionsRow.removeAllViews()
        for ((i, a) in actions.withIndex()) {
            val b = TextView(context)
            b.text = a.title
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            b.typeface = Typeface.create(Typeface.DEFAULT, 600, false)
            b.setSingleLine(true)
            b.ellipsize = TextUtils.TruncateAt.END
            b.gravity = Gravity.CENTER
            b.setTextColor(if (dark) Color.WHITE else Color.BLACK)
            val pill = GradientDrawable()
            pill.shape = GradientDrawable.RECTANGLE
            pill.cornerRadius = context.dp(14).toFloat()
            pill.setColor(if (dark) Color.argb(60, 255, 255, 255) else Color.argb(18, 0, 0, 0))
            b.background = pill
            b.setPadding(context.dp(12), context.dp(8), context.dp(12), context.dp(8))
            b.isClickable = true
            b.contentDescription = a.title
            b.setOnClickListener { onActionClick?.invoke(a) }
            val lp = LLP(0, LLP.WRAP_CONTENT, 1f)
            if (i > 0) lp.leftMargin = context.dp(8)
            actionsRow.addView(b, lp)
        }
        actionsRow.visibility = if (expanded && actions.isNotEmpty()) View.VISIBLE else View.GONE
    }

    fun bind(d: CardData, dark: Boolean, blur: Boolean) {
        // Material translúcido (valores aproximados do cartão escuro/claro do iOS).
        val bg = if (dark) {
            Color.argb(if (blur) 165 else 235, 44, 44, 46)
        } else {
            Color.argb(if (blur) 175 else 240, 246, 246, 248)
        }
        val stroke = if (dark) Color.argb(36, 255, 255, 255) else Color.argb(22, 0, 0, 0)
        val shape = GradientDrawable()
        shape.shape = GradientDrawable.RECTANGLE
        shape.cornerRadius = context.dp(26).toFloat()
        shape.setColor(bg)
        shape.setStroke(1, stroke)
        background = shape

        title.setTextColor(if (dark) Color.WHITE else Color.BLACK)
        body.setTextColor(if (dark) Color.argb(235, 255, 255, 255) else Color.argb(230, 0, 0, 0))
        meta.setTextColor(
            if (dark) Color.argb(153, 235, 235, 245) else Color.argb(153, 60, 60, 67)
        )

        title.text = d.title
        // Se o título já é o nome do app, não repete o nome na linha de cima.
        meta.text = if (d.title.equals(d.appName, ignoreCase = true)) "agora" else d.appName + " · agora"
        if (d.body.isBlank()) {
            body.visibility = View.GONE
        } else {
            body.visibility = View.VISIBLE
            body.text = d.body
        }

        if (d.avatar != null) {
            // Foto do contato em círculo + selo do app no canto.
            avatar.setImageDrawable(d.avatar)
            avatar.outlineProvider = roundOutline(context.dp(22).toFloat())
            badge.setImageDrawable(d.appIcon)
            badge.visibility = if (d.appIcon != null) View.VISIBLE else View.GONE
        } else {
            // Sem foto: ícone do app em quadrado arredondado.
            avatar.setImageDrawable(d.appIcon)
            avatar.outlineProvider = roundOutline(context.dp(10).toFloat())
            badge.visibility = View.GONE
        }

        actions = d.actions
        rebuildActions(dark)
    }

    private fun roundOutline(radius: Float): ViewOutlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radius)
        }
    }
}
