package app.iosbanners

import android.app.ActivityOptions
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.Log

/** Uma ação (botão) da notificação original, reapresentada no cartão. */
data class CardAction(val title: String, val intent: PendingIntent)

/** Dados já extraídos de uma notificação real, prontos para desenhar o cartão. */
data class CardData(
    val key: String,
    val packageName: String,
    val appName: String,
    val title: String,
    val body: String,
    val appIcon: Drawable?,
    val avatar: Drawable?,
    val contentIntent: PendingIntent?,
    val postTime: Long,
    /** Ações do app de origem (sem as de resposta por texto), no máximo [ActionPolicy.MAX_ACTIONS]. */
    val actions: List<CardAction> = emptyList(),
    /** A original pode ser dispensada depois do cartão? (veja NotificationPolicy; false = fica na central) */
    val cancelAllowed: Boolean = true
)

/** Passagem de dados do serviço para a LockCardActivity (mesmo processo). */
object CardStore {
    @Volatile
    var pending: CardData? = null
}

/** Dispara um PendingIntent do app de origem (toque no cartão ou numa ação). false = o sistema recusou. */
fun sendPendingIntent(ctx: Context, pi: PendingIntent): Boolean = try {
    val opts = ActivityOptions.makeBasic()
    if (Build.VERSION.SDK_INT >= 34) {
        opts.setPendingIntentBackgroundActivityStartMode(
            ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
        )
    }
    pi.send(ctx, 0, null, null, null, null, opts.toBundle())
    true
} catch (e: Exception) {
    Log.w("IosBanners", "PendingIntent falhou", e)
    false
}

/** Abre o app de origem: usa o PendingIntent original; se faltar, a intent de lançamento do pacote. */
fun openSource(ctx: Context, d: CardData) {
    val pi = d.contentIntent
    if (pi != null && sendPendingIntent(ctx, pi)) return
    try {
        val launch = ctx.packageManager.getLaunchIntentForPackage(d.packageName)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(launch)
        }
    } catch (e: Exception) {
        Log.w("IosBanners", "Não foi possível abrir ${d.packageName}", e)
    }
}
