package app.iosbanners

/**
 * Modo de apresentação das notificações, escolhido pelo usuário (veja Prefs.notificationMode).
 *
 * Este arquivo e ModeController.kt não usam nenhuma classe do Android: assim a lógica de troca de
 * modo roda em testes unitários comuns da JVM (app/src/test).
 */
enum class NotificationMode(val id: String) {
    /** Cartão estilo iOS. A original só é dispensada depois que o cartão apareceu (veja RemovalPolicy). */
    IOS("ios"),

    /** Comportamento nativo do Android/One UI: o app não mostra cartão e não remove nada. */
    SAMSUNG("samsung");

    companion object {
        /** Padrão: iOS, que é o que o app já fazia antes de existir a escolha (ninguém perde o que usava). */
        val DEFAULT: NotificationMode = IOS

        /** Valor desconhecido ou ausente cai no padrão, em vez de quebrar. */
        fun fromId(id: String?): NotificationMode = values().firstOrNull { it.id == id } ?: DEFAULT
    }
}

/** O que precisa estar pronto para o modo iOS realmente mostrar cartões. */
enum class Requirement { MASTER_SWITCH, LISTENER_ACCESS, OVERLAY_PERMISSION }

/**
 * Estado efetivo do modo, para a tela mostrar a verdade: no modo iOS sem permissões nada é exibido
 * e nada é removido (as originais seguem normais), e a tela precisa dizer isso.
 */
data class ModeStatus(val mode: NotificationMode, val missing: List<Requirement>) {

    /** true = o cartão iOS está de fato em funcionamento. */
    val presenting: Boolean get() = mode == NotificationMode.IOS && missing.isEmpty()

    companion object {
        fun of(
            mode: NotificationMode,
            masterEnabled: Boolean,
            listenerGranted: Boolean,
            overlayGranted: Boolean
        ): ModeStatus {
            // Modo Samsung não depende de nada: é o comportamento nativo do sistema.
            if (mode == NotificationMode.SAMSUNG) return ModeStatus(mode, emptyList())
            val missing = ArrayList<Requirement>()
            if (!masterEnabled) missing.add(Requirement.MASTER_SWITCH)
            if (!listenerGranted) missing.add(Requirement.LISTENER_ACCESS)
            if (!overlayGranted) missing.add(Requirement.OVERLAY_PERMISSION)
            return ModeStatus(mode, missing)
        }
    }
}
