package app.iosbanners

/**
 * Chave de Settings.Global que liga/desliga os pop-ups (heads-up) de TODOS os apps. Este app NÃO a
 * escreve para desligar nada: só a usa para LER o estado e, se uma versão anterior deste app a tiver
 * desligado, para RESTAURAR (veja ModeController). Fica aqui, sem Android, para os testes na JVM.
 */
const val SYSTEM_POPUPS_SETTING_KEY = "heads_up_notifications_enabled"

/**
 * Configuração "Substituir notificações nativas" (veja Prefs.notificationMode).
 *
 * - [IOS] = ATIVADO: apresenta os banners do iOS Banners e dispensa a original só quando é
 *   permitido e seguro (veja NotificationPolicy e RemovalPolicy).
 * - [SAMSUNG] = DESATIVADO: o app não lê, não mostra e não remove nada; vale o comportamento
 *   nativo normal do Android/One UI.
 *
 * Os identificadores gravados ("ios"/"samsung") continuam os mesmos das versões anteriores.
 *
 * Este arquivo e ModeController.kt não usam nenhuma classe do Android: assim a lógica de troca de
 * modo roda em testes unitários comuns da JVM (app/src/test).
 */
enum class NotificationMode(val id: String, val label: String) {
    /** ATIVADO. */
    IOS("ios", "ATIVADO"),

    /** DESATIVADO: comportamento nativo do Android/One UI. */
    SAMSUNG("samsung", "DESATIVADO");

    companion object {
        /**
         * Padrão: DESATIVADO. Uma instalação nova não troca nenhuma notificação até o usuário
         * escolher ATIVADO (e conceder as permissões). Valor desconhecido também cai aqui.
         */
        val DEFAULT: NotificationMode = SAMSUNG

        fun fromId(id: String?): NotificationMode = values().firstOrNull { it.id == id } ?: DEFAULT

        /**
         * Resolve o modo ao ler as preferências. Versões anteriores tinham uma chave principal
         * ("Ativar banners estilo iOS") além do modo, e o cartão só valia com as DUAS ligadas
         * (sem modo salvo, o padrão era iOS). Na primeira leitura depois da atualização
         * ([migrated] = false) as duas viram uma só escolha, sem mudar o que o usuário via:
         * ATIVADO só se o modo era iOS E a chave principal estava ligada.
         */
        fun resolve(storedId: String?, legacyEnabled: Boolean, migrated: Boolean): NotificationMode {
            if (migrated) return fromId(storedId)
            val legacyIsIos = storedId != SAMSUNG.id
            return if (legacyEnabled && legacyIsIos) IOS else SAMSUNG
        }
    }
}

/** O que precisa estar pronto para o modo ATIVADO realmente mostrar cartões. */
enum class Requirement { LISTENER_ACCESS, OVERLAY_PERMISSION }

/**
 * Estado efetivo do modo, para a tela mostrar a verdade: ATIVADO sem permissões não exibe nem remove
 * nada (as originais seguem normais), e a tela precisa dizer isso.
 */
data class ModeStatus(val mode: NotificationMode, val missing: List<Requirement>) {

    /** true = o cartão iOS está de fato em funcionamento. */
    val presenting: Boolean get() = mode == NotificationMode.IOS && missing.isEmpty()

    companion object {
        fun of(mode: NotificationMode, listenerGranted: Boolean, overlayGranted: Boolean): ModeStatus {
            // DESATIVADO não depende de nada: é o comportamento nativo do sistema.
            if (mode == NotificationMode.SAMSUNG) return ModeStatus(mode, emptyList())
            val missing = ArrayList<Requirement>()
            if (!listenerGranted) missing.add(Requirement.LISTENER_ACCESS)
            if (!overlayGranted) missing.add(Requirement.OVERLAY_PERMISSION)
            return ModeStatus(mode, missing)
        }
    }
}
