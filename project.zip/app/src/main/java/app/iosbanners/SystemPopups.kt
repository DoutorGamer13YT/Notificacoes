package app.iosbanners

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

/**
 * Ajuste global do Android que liga/desliga os pop-ups (heads-up) de TODOS os apps.
 *
 * Esta versão do app NÃO desliga este ajuste (e o modo ATIVADO nunca mexe nele): desligar pop-ups de
 * todos os apps afetaria também chamadas e alarmes, e a permissão WRITE_SECURE_SETTINGS não é uma
 * forma segura nem comprovada de "desativar notificações" de outros apps. Aqui ele só serve para:
 *  - LER o estado (o ranking de uma notificação diz se a original faria pop-up);
 *  - RESTAURAR (valor 1) se uma versão anterior do app o tiver desligado, ou se o usuário pedir.
 *
 * Não é uma API documentada do SDK: é a chave "heads_up_notifications_enabled" de Settings.Global
 * ([SYSTEM_POPUPS_SETTING_KEY]). Escrever nela exige WRITE_SECURE_SETTINGS, que o Android só concede
 * por adb (não existe tela para isso). A permissão "modificar configurações do sistema"
 * (WRITE_SETTINGS) NÃO serve: ela só escreve em Settings.System.
 */
object SystemPopups {
    const val KEY = SYSTEM_POPUPS_SETTING_KEY

    fun hasPermission(c: Context): Boolean =
        c.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    /** true = pop-ups do sistema desligados (valor 0). Sem o ajuste gravado, o padrão do Android é ligado. */
    fun disabled(c: Context): Boolean = try {
        Settings.Global.getInt(c.contentResolver, KEY, 1) == 0
    } catch (e: Exception) {
        false
    }

    /** Religa o ajuste (valor 1). Devolve false se o sistema recusar (permissão não concedida). */
    fun restore(c: Context): Boolean = try {
        Settings.Global.putInt(c.contentResolver, KEY, 1)
    } catch (e: Exception) {
        false
    }
}
