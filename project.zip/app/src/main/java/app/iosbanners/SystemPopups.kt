package app.iosbanners

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

/**
 * Ajuste global do Android que liga/desliga os pop-ups (heads-up) de TODOS os apps.
 *
 * Não é uma API documentada do SDK: é a chave "heads_up_notifications_enabled" de Settings.Global,
 * usada por apps e guias que desligam pop-ups. Escrever nela exige a permissão
 * WRITE_SECURE_SETTINGS, que o Android só concede por adb (não existe tela para isso). A permissão
 * "modificar configurações do sistema" (WRITE_SETTINGS) NÃO serve: ela só escreve em Settings.System.
 *
 * Desligado (0): o pop-up original some, mas som, central de notificações e respostas rápidas ficam
 * como estão. O cartão estilo iOS é uma janela do próprio app e não é afetado. O valor fica gravado
 * no sistema mesmo se o app for desinstalado.
 */
object SystemPopups {
    const val KEY = "heads_up_notifications_enabled"

    fun hasPermission(c: Context): Boolean =
        c.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    /** true = pop-ups do sistema desligados (valor 0). Sem o ajuste gravado, o padrão do Android é ligado. */
    fun disabled(c: Context): Boolean = try {
        Settings.Global.getInt(c.contentResolver, KEY, 1) == 0
    } catch (e: Exception) {
        false
    }

    /** Grava o ajuste. Devolve false se o sistema recusar (permissão não concedida). */
    fun setDisabled(c: Context, disabled: Boolean): Boolean = try {
        Settings.Global.putInt(c.contentResolver, KEY, if (disabled) 0 else 1)
    } catch (e: Exception) {
        false
    }
}
