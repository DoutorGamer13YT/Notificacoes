package app.iosbanners

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.provider.Settings

/** Liga o ModeController ao Android real (preferências, permissões e serviço de notificações). */
class AndroidModeEnvironment(context: Context) : ModeEnvironment {

    private val c: Context = context.applicationContext

    override fun mode(): NotificationMode = Prefs.notificationMode(c)

    override fun saveMode(mode: NotificationMode): Boolean = Prefs.setNotificationMode(c, mode)

    override fun listenerGranted(): Boolean = try {
        c.getSystemService(NotificationManager::class.java)
            ?.isNotificationListenerAccessGranted(ComponentName(c, NotificationService::class.java)) == true
    } catch (e: Exception) {
        false
    }

    override fun overlayGranted(): Boolean = try {
        Settings.canDrawOverlays(c)
    } catch (e: Exception) {
        false
    }

    override fun popupsPermissionGranted(): Boolean = SystemPopups.hasPermission(c)

    override fun popupsDisabledInSystem(): Boolean = SystemPopups.disabled(c)

    override fun restoreSystemPopups(): Boolean = SystemPopups.restore(c)

    override fun popupsOwnedByApp(): Boolean = Prefs.systemPopupsOwned(c)

    override fun setPopupsOwnedByApp(value: Boolean) {
        Prefs.setSystemPopupsOwned(c, value)
    }

    override fun resetPresentation() {
        NotificationService.resetPresentation()
    }
}
