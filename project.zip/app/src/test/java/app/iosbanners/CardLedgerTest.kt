package app.iosbanners

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Duplicidade e repetição: as regras que impedem dois avisos do mesmo evento (e a perda de um). */
class CardLedgerTest {

    private val key = "0|com.exemplo|1|null|10001"

    @Test
    fun `a mesma atualização repetida é reconhecida e não gera outro cartão`() {
        val l = CardLedger()
        assertFalse(l.isSameEvent(key, 42))
        l.startEvent(key, 42, 1000L)
        assertTrue(l.isSameEvent(key, 42))
        assertFalse("conteúdo diferente é evento novo", l.isSameEvent(key, 43))
    }

    @Test
    fun `chaves diferentes com o mesmo texto não se bloqueiam`() {
        val l = CardLedger()
        l.startEvent("a", 42, 1000L)
        assertFalse(l.isSameEvent("b", 42))
    }

    @Test
    fun `original republicada depois de removida por nós é reconhecida`() {
        val l = CardLedger()
        l.startEvent(key, 42, 1000L)
        l.markRemovedByUs(key)
        // O sistema avisa que a notificação saiu (fomos nós): o estado é mantido.
        l.onRemoved(key)
        assertTrue(l.isCarded(key))
        // O app republica o mesmo evento (mesmo "when"): remove de novo, sem outro cartão.
        assertTrue(l.isRepublishOfCarded(key, 1000L))
        assertTrue(l.isSameEvent(key, 42))
    }

    @Test
    fun `evento com outro horário não é tratado como republicação`() {
        val l = CardLedger()
        l.startEvent(key, 42, 1000L)
        l.markRemovedByUs(key)
        assertFalse(l.isRepublishOfCarded(key, 2000L))
        assertFalse(l.isRepublishOfCarded(key, null))
    }

    @Test
    fun `remoção feita pelo app ou pelo usuário zera o estado e o próximo post é evento novo`() {
        val l = CardLedger()
        l.startEvent(key, 42, 1000L)
        l.markRemovedByUs(key)
        l.onRemoved(key) // consome a marca "fomos nós"
        l.onRemoved(key) // agora foi o usuário/app
        assertFalse(l.isSameEvent(key, 42))
        assertFalse(l.isCarded(key))
        assertFalse(l.isRepublishOfCarded(key, 1000L))
    }

    @Test
    fun `onRemoved diz se a remoção foi nossa ou do app de origem`() {
        val l = CardLedger()
        l.startEvent(key, 42, 1000L)
        l.markRemovedByUs(key)
        assertTrue("fomos nós: o cartão na tela não precisa sair por isso", l.onRemoved(key))
        assertFalse("o app (ou o usuário) removeu: o cartão dessa chave perdeu o sentido", l.onRemoved(key))
        assertFalse("chave desconhecida também não foi nossa", l.onRemoved("outra"))
    }

    @Test
    fun `evento novo na mesma chave volta a exigir cartão`() {
        val l = CardLedger()
        l.startEvent(key, 42, 1000L)
        l.markRemovedByUs(key)
        l.startEvent(key, 99, 2000L)
        assertFalse(l.isCarded(key))
        assertFalse(l.isRepublishOfCarded(key, 2000L))
    }

    @Test
    fun `falha ao remover desfaz a marca`() {
        val l = CardLedger()
        l.startEvent(key, 42, 1000L)
        l.markRemovedByUs(key)
        l.unmarkRemovedByUs(key)
        assertFalse(l.isCarded(key))
    }

    @Test
    fun `trocar de modo limpa tudo e nada fica tratado como já exibido`() {
        val l = CardLedger()
        l.startEvent(key, 42, 1000L)
        l.markRemovedByUs(key)
        l.markTest("teste")
        l.clear()
        // Sem isso, ao voltar para o iOS uma notificação que ficou na central durante o modo Samsung
        // seria removida em silêncio, sem nenhum cartão: notificação perdida.
        assertFalse(l.isRepublishOfCarded(key, 1000L))
        assertFalse(l.isSameEvent(key, 42))
        assertFalse(l.isCarded(key))
        assertFalse(l.consumeTest("teste"))
    }

    @Test
    fun `estado muito grande é descartado em vez de crescer sem limite`() {
        val l = CardLedger(maxEntries = 3)
        for (i in 1..5) l.startEvent("k$i", i, i.toLong())
        assertFalse("o mais antigo foi esquecido", l.isSameEvent("k1", 1))
        assertTrue("o mais recente continua", l.isSameEvent("k5", 5))
    }

    @Test
    fun `a notificação de teste sai uma vez só`() {
        val l = CardLedger()
        l.markTest("t")
        assertTrue(l.consumeTest("t"))
        assertFalse(l.consumeTest("t"))
    }

    @Test
    fun `sequência completa sem duplicar e sem perder`() {
        val l = CardLedger()
        // 1) chega o evento: vira cartão, original removida.
        assertFalse(l.isSameEvent(key, 7))
        l.startEvent(key, 7, 500L)
        l.markRemovedByUs(key)
        l.onRemoved(key)
        // 2) o app republica igual: só remove a original de novo (sem outro cartão).
        assertTrue(l.isSameEvent(key, 7))
        assertTrue(l.isCarded(key))
        // 3) chega mensagem nova na mesma conversa: evento novo, novo cartão.
        assertFalse(l.isSameEvent(key, 8))
        l.startEvent(key, 8, 900L)
        assertFalse(l.isCarded(key))
        assertEquals(false, l.isRepublishOfCarded(key, 500L))
    }
}
