package app.iosbanners

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Quando a original pode ser dispensada: nunca no modo Samsung, e só com critério no modo iOS. */
class RemovalPolicyTest {

    private fun decide(
        active: Boolean,
        test: Boolean = false,
        exclusive: Boolean = true,
        popsUp: Boolean = true
    ): Pair<Boolean, Int> {
        var asked = 0
        val r = RemovalPolicy.shouldRemove(active, test, exclusive) {
            asked++
            popsUp
        }
        return Pair(r, asked)
    }

    @Test
    fun `modo Samsung nunca remove nada, nem a de teste, e nem consulta o ranking`() {
        assertEquals(Pair(false, 0), decide(active = false))
        assertEquals(Pair(false, 0), decide(active = false, test = true))
        assertEquals(Pair(false, 0), decide(active = false, exclusive = false))
    }

    @Test
    fun `modo iOS remove a original que faria pop-up`() {
        assertEquals(Pair(true, 1), decide(active = true, popsUp = true))
    }

    @Test
    fun `modo iOS mantém na central a original de canal sem pop-up`() {
        assertEquals(Pair(false, 1), decide(active = true, popsUp = false))
    }

    @Test
    fun `sem o modo exclusivo nenhuma original é removida`() {
        assertEquals(Pair(false, 0), decide(active = true, exclusive = false))
    }

    @Test
    fun `a notificação de teste do próprio app sai sempre no modo iOS`() {
        assertTrue(decide(active = true, test = true, exclusive = false, popsUp = false).first)
        assertEquals(0, decide(active = true, test = true).second)
    }

    @Test
    fun `desligar o recurso equivale ao modo Samsung`() {
        assertFalse(decide(active = false, popsUp = true).first)
    }
}
