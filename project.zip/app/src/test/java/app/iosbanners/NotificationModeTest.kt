package app.iosbanners

import org.junit.Assert.assertEquals
import org.junit.Test

/** Migração das preferências de versões anteriores (modo + chave principal) para uma escolha só. */
class NotificationModeTest {

    private val ios = NotificationMode.IOS
    private val off = NotificationMode.SAMSUNG

    @Test
    fun `antes da migração só vale ATIVADO se o modo era iOS e a chave principal estava ligada`() {
        // (modo salvo, chave principal) -> resultado. Sem modo salvo, a versão anterior assumia iOS.
        assertEquals(ios, NotificationMode.resolve("ios", legacyEnabled = true, migrated = false))
        assertEquals(ios, NotificationMode.resolve(null, legacyEnabled = true, migrated = false))
        assertEquals(off, NotificationMode.resolve("ios", legacyEnabled = false, migrated = false))
        assertEquals(off, NotificationMode.resolve(null, legacyEnabled = false, migrated = false))
        assertEquals(off, NotificationMode.resolve("samsung", legacyEnabled = true, migrated = false))
        assertEquals(off, NotificationMode.resolve("samsung", legacyEnabled = false, migrated = false))
    }

    @Test
    fun `valor desconhecido na versão anterior valia iOS, então segue a chave principal`() {
        assertEquals(ios, NotificationMode.resolve("lixo", legacyEnabled = true, migrated = false))
        assertEquals(off, NotificationMode.resolve("lixo", legacyEnabled = false, migrated = false))
    }

    @Test
    fun `depois da migração só o modo salvo vale e a chave antiga é ignorada`() {
        assertEquals(ios, NotificationMode.resolve("ios", legacyEnabled = false, migrated = true))
        assertEquals(off, NotificationMode.resolve("samsung", legacyEnabled = true, migrated = true))
        assertEquals(off, NotificationMode.resolve(null, legacyEnabled = true, migrated = true))
        assertEquals(off, NotificationMode.resolve("lixo", legacyEnabled = true, migrated = true))
    }

    @Test
    fun `a migração é estável quando repetida (o resultado gravado resolve para o mesmo modo)`() {
        for (stored in listOf(null, "ios", "samsung", "lixo")) {
            for (legacy in listOf(true, false)) {
                val first = NotificationMode.resolve(stored, legacy, migrated = false)
                // O Prefs grava first.id e marca como migrado: ler de novo tem de dar o mesmo.
                assertEquals(first, NotificationMode.resolve(first.id, legacy, migrated = true))
            }
        }
    }

    @Test
    fun `os identificadores gravados continuam os das versões anteriores`() {
        assertEquals("ios", NotificationMode.IOS.id)
        assertEquals("samsung", NotificationMode.SAMSUNG.id)
    }
}
