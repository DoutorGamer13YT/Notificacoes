package app.iosbanners

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ModeControllerTest {

    // ---------- Modo padrão e estado ----------

    @Test
    fun `sem valor salvo ou com valor desconhecido o padrão é iOS`() {
        assertEquals(NotificationMode.IOS, NotificationMode.fromId(null))
        assertEquals(NotificationMode.IOS, NotificationMode.fromId(""))
        assertEquals(NotificationMode.IOS, NotificationMode.fromId("lixo"))
        assertEquals(NotificationMode.IOS, NotificationMode.fromId("ios"))
        assertEquals(NotificationMode.SAMSUNG, NotificationMode.fromId("samsung"))
    }

    @Test
    fun `estado do modo Samsung nunca depende de permissões`() {
        val st = ModeStatus.of(NotificationMode.SAMSUNG, false, false, false)
        assertTrue(st.missing.isEmpty())
        assertFalse(st.presenting)
    }

    @Test
    fun `estado do modo iOS lista o que falta e só apresenta com tudo pronto`() {
        assertTrue(ModeStatus.of(NotificationMode.IOS, true, true, true).presenting)
        assertEquals(
            listOf(Requirement.MASTER_SWITCH, Requirement.LISTENER_ACCESS, Requirement.OVERLAY_PERMISSION),
            ModeStatus.of(NotificationMode.IOS, false, false, false).missing
        )
        assertEquals(
            listOf(Requirement.LISTENER_ACCESS),
            ModeStatus.of(NotificationMode.IOS, true, false, true).missing
        )
        assertFalse(ModeStatus.of(NotificationMode.IOS, true, true, false).presenting)
    }

    // ---------- Modo Samsung ----------

    @Test
    fun `escolher Samsung fecha o cartão, salva o modo e não mexe na chave principal`() {
        val env = FakeModeEnvironment(master = true)
        val r = ModeController(env).select(NotificationMode.SAMSUNG)
        assertTrue(r.ok)
        assertEquals(NotificationMode.SAMSUNG, env.storedMode)
        assertEquals(1, env.resetCalls)
        assertTrue(env.master)
        assertTrue(r.missing.isEmpty())
    }

    @Test
    fun `Samsung não mexe no ajuste do sistema que o app não alterou`() {
        // Pop-up desligado por fora (por exemplo, por adb): não é do app, fica como está.
        val env = FakeModeEnvironment(systemPopupsOff = true, owned = false)
        ModeController(env).select(NotificationMode.SAMSUNG)
        assertTrue(env.systemPopupsOff)
        assertEquals(0, env.systemWrites)
    }

    @Test
    fun `Samsung restaura o pop-up do sistema que o próprio app desligou`() {
        val env = FakeModeEnvironment(systemPopupsOff = true, owned = true, wanted = true)
        val r = ModeController(env).select(NotificationMode.SAMSUNG)
        assertTrue(r.ok)
        assertFalse(env.systemPopupsOff)
        assertFalse(env.owned)
        assertTrue("a vontade do usuário é preservada para quando voltar ao iOS", env.wanted)
        assertFalse(r.popupsRestorePending)
        assertTrue(r.notes.contains(ModeController.MSG_POPUPS_RESTORED))
    }

    @Test
    fun `Samsung sem a permissão especial mantém o modo e avisa que falta restaurar`() {
        val env = FakeModeEnvironment(systemPopupsOff = true, owned = true, secureSettings = false)
        val r = ModeController(env).select(NotificationMode.SAMSUNG)
        assertTrue(r.ok)
        assertEquals(NotificationMode.SAMSUNG, env.storedMode)
        assertTrue(r.popupsRestorePending)
        assertTrue("continua sendo do app, para tentar de novo depois", env.owned)
        assertTrue(r.notes.any { it.contains("adb shell settings put global") })
    }

    @Test
    fun `Samsung só limpa o registro quando o ajuste já tinha sido restaurado por fora`() {
        val env = FakeModeEnvironment(systemPopupsOff = false, owned = true)
        val r = ModeController(env).select(NotificationMode.SAMSUNG)
        assertFalse(env.owned)
        assertEquals(0, env.systemWrites)
        assertFalse(r.popupsRestorePending)
    }

    // ---------- Modo iOS ----------

    @Test
    fun `escolher iOS liga o recurso e não mexe no sistema se o usuário nunca ligou a opção avançada`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.SAMSUNG, master = false, wanted = false)
        val r = ModeController(env).select(NotificationMode.IOS)
        assertTrue(r.ok)
        assertEquals(NotificationMode.IOS, env.storedMode)
        assertTrue(env.master)
        assertEquals(0, env.systemWrites)
        assertTrue(r.missing.isEmpty())
    }

    @Test
    fun `iOS religa o ajuste de pop-ups só se o usuário tinha ligado a opção avançada`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.SAMSUNG, wanted = true)
        val r = ModeController(env).select(NotificationMode.IOS)
        assertTrue(env.systemPopupsOff)
        assertTrue(env.owned)
        assertTrue(r.notes.contains(ModeController.MSG_POPUPS_REAPPLIED))
    }

    @Test
    fun `iOS não assume como seu um ajuste que já estava desligado por fora`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.SAMSUNG, wanted = true, systemPopupsOff = true)
        ModeController(env).select(NotificationMode.IOS)
        assertFalse(env.owned)
        assertEquals(0, env.systemWrites)
    }

    @Test
    fun `iOS sem permissões salva a escolha, diz o que falta e nada é concedido sozinho`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.SAMSUNG, listener = false, overlay = false)
        val r = ModeController(env).select(NotificationMode.IOS)
        assertTrue(r.ok)
        assertEquals(NotificationMode.IOS, env.storedMode)
        assertEquals(listOf(Requirement.LISTENER_ACCESS, Requirement.OVERLAY_PERMISSION), r.missing)
        assertFalse(ModeController(env).status().presenting)
        assertFalse(env.listener)
        assertFalse(env.overlay)
    }

    @Test
    fun `iOS sem a permissão especial avisa e segue sem derrubar a troca`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.SAMSUNG, wanted = true, secureSettings = false)
        val r = ModeController(env).select(NotificationMode.IOS)
        assertTrue(r.ok)
        assertEquals(NotificationMode.IOS, env.storedMode)
        assertTrue(r.notes.contains(ModeController.MSG_POPUPS_REAPPLY_FAILED))
        assertFalse(env.owned)
    }

    // ---------- Erros ----------

    @Test
    fun `falha ao salvar mantém o modo anterior e não muda mais nada`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.IOS, systemPopupsOff = true, owned = true)
        env.failSave = true
        val r = ModeController(env).select(NotificationMode.SAMSUNG)
        assertFalse(r.ok)
        assertEquals(NotificationMode.IOS, r.mode)
        assertEquals(NotificationMode.IOS, env.storedMode)
        assertEquals(0, env.resetCalls)
        assertEquals(0, env.systemWrites)
        assertTrue(env.systemPopupsOff)
        assertTrue(r.notes.contains(ModeController.MSG_SAVE_FAILED))
    }

    @Test
    fun `falha ao fechar o cartão não desfaz a troca de modo`() {
        val env = FakeModeEnvironment(systemPopupsOff = true, owned = true)
        env.failReset = true
        val r = ModeController(env).select(NotificationMode.SAMSUNG)
        assertTrue(r.ok)
        assertEquals(NotificationMode.SAMSUNG, env.storedMode)
        assertTrue(r.notes.contains(ModeController.MSG_RESET_FAILED))
        // Mesmo com a falha, a restauração do que o app alterou continua acontecendo.
        assertFalse(env.systemPopupsOff)
    }

    // ---------- Alternância repetida ----------

    @Test
    fun `alternar muitas vezes termina sempre num estado coerente`() {
        // Ponto de partida: o usuário ligou a opção avançada (sistema desligado e o app é o dono).
        val env = FakeModeEnvironment(wanted = true, systemPopupsOff = true, owned = true)
        val c = ModeController(env)
        repeat(200) { i ->
            val target = if (i % 2 == 0) NotificationMode.SAMSUNG else NotificationMode.IOS
            val r = c.select(target)
            assertTrue(r.ok)
            assertEquals(target, env.storedMode)
            assertTrue(env.master)
            assertTrue(env.wanted)
            if (target == NotificationMode.SAMSUNG) {
                assertFalse("Samsung deixa o sistema como era", env.systemPopupsOff)
                assertFalse(env.owned)
            } else {
                assertTrue("iOS volta a desligar o que o usuário pediu", env.systemPopupsOff)
                assertTrue(env.owned)
            }
        }
        // Cada troca limpou o estado interno do serviço (sem sobras entre um modo e outro).
        assertEquals(200, env.resetCalls)
        assertEquals(NotificationMode.IOS, env.storedMode)
    }

    @Test
    fun `escolher duas vezes o mesmo modo é inofensivo`() {
        val env = FakeModeEnvironment(systemPopupsOff = true, owned = true, wanted = true)
        val c = ModeController(env)
        c.select(NotificationMode.SAMSUNG)
        val writes = env.systemWrites
        c.select(NotificationMode.SAMSUNG)
        assertEquals("não escreve no sistema de novo", writes, env.systemWrites)
        assertEquals(NotificationMode.SAMSUNG, env.storedMode)
        assertFalse(env.systemPopupsOff)
    }

    // ---------- Reinício ----------

    @Test
    fun `reiniciar o aparelho mantém o modo escolhido nos dois sentidos`() {
        val env = FakeModeEnvironment()
        ModeController(env).select(NotificationMode.SAMSUNG)

        // "Reinício": outro controlador sobre os mesmos dados salvos.
        val afterBoot = ModeController(env)
        assertEquals(NotificationMode.SAMSUNG, afterBoot.status().mode)
        val writes = env.systemWrites
        assertTrue(afterBoot.reconcile().ok)
        assertTrue(afterBoot.reconcile().ok)
        assertEquals(NotificationMode.SAMSUNG, env.storedMode)
        assertEquals("reaplicar é idempotente", writes, env.systemWrites)

        ModeController(env).select(NotificationMode.IOS)
        val afterSecondBoot = ModeController(env)
        assertEquals(NotificationMode.IOS, afterSecondBoot.status().mode)
        assertTrue(afterSecondBoot.reconcile().ok)
        assertEquals(NotificationMode.IOS, env.storedMode)
    }

    @Test
    fun `depois de reiniciar no modo Samsung restaura o que ficou pelo meio`() {
        // O app foi encerrado no meio da troca: modo já é Samsung, mas o pop-up segue desligado.
        val env = FakeModeEnvironment(storedMode = NotificationMode.SAMSUNG, systemPopupsOff = true, owned = true)
        val r = ModeController(env).reconcile()
        assertTrue(r.ok)
        assertFalse(env.systemPopupsOff)
        assertFalse(env.owned)
    }

    @Test
    fun `depois de reiniciar no modo iOS respeita um ajuste restaurado por fora`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.IOS, owned = true, wanted = true, systemPopupsOff = false)
        ModeController(env).reconcile()
        assertFalse(env.owned)
        assertFalse(env.wanted)
        assertEquals("não briga com o usuário", 0, env.systemWrites)
    }

    @Test
    fun `reinício sem permissões mantém o modo escolhido e só mostra o estado`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.IOS, listener = false, overlay = false)
        val c = ModeController(env)
        val r = c.reconcile()
        assertEquals(NotificationMode.IOS, env.storedMode)
        assertEquals(listOf(Requirement.LISTENER_ACCESS, Requirement.OVERLAY_PERMISSION), r.missing)
        assertFalse(c.status().presenting)
    }

    // ---------- Botão avançado de pop-ups ----------

    @Test
    fun `desligar pop-ups do sistema é bloqueado no modo Samsung`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.SAMSUNG)
        assertEquals(PopupsOutcome.BLOCKED_BY_SAMSUNG_MODE, ModeController(env).setSystemPopupsDisabled(true))
        assertFalse(env.systemPopupsOff)
        assertEquals(0, env.systemWrites)
    }

    @Test
    fun `desligar pop-ups do sistema pede a permissão quando ela falta`() {
        val env = FakeModeEnvironment(secureSettings = false)
        assertEquals(PopupsOutcome.NEEDS_PERMISSION, ModeController(env).setSystemPopupsDisabled(true))
        assertFalse(env.owned)
        assertFalse(env.wanted)
    }

    @Test
    fun `ligar e restaurar pop-ups do sistema atualiza os registros do app`() {
        val env = FakeModeEnvironment()
        val c = ModeController(env)
        assertEquals(PopupsOutcome.DONE, c.setSystemPopupsDisabled(true))
        assertTrue(env.systemPopupsOff && env.owned && env.wanted)
        assertEquals(PopupsOutcome.DONE, c.setSystemPopupsDisabled(false))
        assertFalse(env.systemPopupsOff || env.owned || env.wanted)
    }

    @Test
    fun `restaurar sem a permissão especial devolve NEEDS_PERMISSION e não perde o registro`() {
        val env = FakeModeEnvironment(systemPopupsOff = true, owned = true, wanted = true, secureSettings = false)
        assertEquals(PopupsOutcome.NEEDS_PERMISSION, ModeController(env).setSystemPopupsDisabled(false))
        assertTrue(env.owned)
        assertTrue(env.wanted)
        assertTrue(env.systemPopupsOff)
    }
}
