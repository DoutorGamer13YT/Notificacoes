package app.iosbanners

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** "Substituir notificações nativas": ATIVADO (IOS) e DESATIVADO (SAMSUNG). */
class ModeControllerTest {

    // ---------- Padrão e estado ----------

    @Test
    fun `o padrão é DESATIVADO e valor desconhecido também`() {
        assertEquals(NotificationMode.SAMSUNG, NotificationMode.DEFAULT)
        assertEquals(NotificationMode.SAMSUNG, NotificationMode.fromId(null))
        assertEquals(NotificationMode.SAMSUNG, NotificationMode.fromId(""))
        assertEquals(NotificationMode.SAMSUNG, NotificationMode.fromId("lixo"))
        assertEquals(NotificationMode.IOS, NotificationMode.fromId("ios"))
        assertEquals(NotificationMode.SAMSUNG, NotificationMode.fromId("samsung"))
    }

    @Test
    fun `os rótulos mostrados ao usuário são ATIVADO e DESATIVADO`() {
        assertEquals("ATIVADO", NotificationMode.IOS.label)
        assertEquals("DESATIVADO", NotificationMode.SAMSUNG.label)
    }

    @Test
    fun `estado DESATIVADO nunca depende de permissões`() {
        val st = ModeStatus.of(NotificationMode.SAMSUNG, false, false)
        assertTrue(st.missing.isEmpty())
        assertFalse(st.presenting)
    }

    @Test
    fun `estado ATIVADO lista o que falta e só apresenta com tudo pronto`() {
        assertTrue(ModeStatus.of(NotificationMode.IOS, true, true).presenting)
        assertEquals(
            listOf(Requirement.LISTENER_ACCESS, Requirement.OVERLAY_PERMISSION),
            ModeStatus.of(NotificationMode.IOS, false, false).missing
        )
        assertEquals(listOf(Requirement.LISTENER_ACCESS), ModeStatus.of(NotificationMode.IOS, false, true).missing)
        assertEquals(listOf(Requirement.OVERLAY_PERMISSION), ModeStatus.of(NotificationMode.IOS, true, false).missing)
        assertFalse(ModeStatus.of(NotificationMode.IOS, true, false).presenting)
    }

    // ---------- DESATIVADO ----------

    @Test
    fun `DESATIVADO fecha o cartão, salva o modo e não escreve em nada do sistema`() {
        val env = FakeModeEnvironment()
        val r = ModeController(env).select(NotificationMode.SAMSUNG)
        assertTrue(r.ok)
        assertEquals(NotificationMode.SAMSUNG, env.storedMode)
        assertEquals(1, env.resetCalls)
        assertEquals(0, env.systemWrites)
        assertTrue(r.missing.isEmpty())
    }

    @Test
    fun `DESATIVADO não mexe no ajuste do sistema que o app não alterou`() {
        // Pop-up desligado por fora (por exemplo, por adb): não é do app, fica como está.
        val env = FakeModeEnvironment(systemPopupsOff = true, owned = false)
        ModeController(env).select(NotificationMode.SAMSUNG)
        assertTrue(env.systemPopupsOff)
        assertEquals(0, env.systemWrites)
    }

    @Test
    fun `DESATIVADO restaura o pop-up do sistema que uma versão anterior do app desligou`() {
        val env = FakeModeEnvironment(systemPopupsOff = true, owned = true)
        val r = ModeController(env).select(NotificationMode.SAMSUNG)
        assertTrue(r.ok)
        assertFalse(env.systemPopupsOff)
        assertFalse(env.owned)
        assertFalse(r.popupsRestorePending)
        assertTrue(r.notes.contains(ModeController.MSG_POPUPS_RESTORED))
    }

    @Test
    fun `DESATIVADO sem a permissão especial mantém o modo e avisa que falta restaurar`() {
        val env = FakeModeEnvironment(systemPopupsOff = true, owned = true, secureSettings = false)
        val r = ModeController(env).select(NotificationMode.SAMSUNG)
        assertTrue(r.ok)
        assertEquals(NotificationMode.SAMSUNG, env.storedMode)
        assertTrue(r.popupsRestorePending)
        assertTrue("continua sendo do app, para tentar de novo depois", env.owned)
        assertTrue(r.notes.any { it.contains("adb shell settings put global") })
    }

    @Test
    fun `DESATIVADO só limpa o registro quando o ajuste já tinha sido restaurado por fora`() {
        val env = FakeModeEnvironment(systemPopupsOff = false, owned = true)
        val r = ModeController(env).select(NotificationMode.SAMSUNG)
        assertFalse(env.owned)
        assertEquals(0, env.systemWrites)
        assertFalse(r.popupsRestorePending)
    }

    // ---------- ATIVADO ----------

    @Test
    fun `ATIVADO salva o modo e nunca mexe no sistema nem desliga pop-ups de ninguém`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.SAMSUNG)
        val r = ModeController(env).select(NotificationMode.IOS)
        assertTrue(r.ok)
        assertEquals(NotificationMode.IOS, env.storedMode)
        assertEquals(0, env.systemWrites)
        assertFalse("ATIVADO não desliga o pop-up global", env.systemPopupsOff)
        assertFalse(env.owned)
        assertTrue(r.missing.isEmpty())
        assertEquals(1, env.resetCalls)
    }

    @Test
    fun `ATIVADO deixa de manter desligado o ajuste global que uma versão anterior desligou`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.SAMSUNG, systemPopupsOff = true, owned = true)
        val r = ModeController(env).select(NotificationMode.IOS)
        assertFalse(env.systemPopupsOff)
        assertFalse(env.owned)
        assertTrue(r.notes.contains(ModeController.MSG_POPUPS_RESTORED))
    }

    @Test
    fun `ATIVADO não assume como seu um ajuste desligado por fora`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.SAMSUNG, systemPopupsOff = true, owned = false)
        ModeController(env).select(NotificationMode.IOS)
        assertTrue(env.systemPopupsOff)
        assertEquals(0, env.systemWrites)
    }

    @Test
    fun `ATIVADO sem permissões salva a escolha, diz o que falta e nada é concedido sozinho`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.SAMSUNG, listener = false, overlay = false)
        val r = ModeController(env).select(NotificationMode.IOS)
        assertTrue(r.ok)
        assertEquals(NotificationMode.IOS, env.storedMode)
        assertEquals(listOf(Requirement.LISTENER_ACCESS, Requirement.OVERLAY_PERMISSION), r.missing)
        assertFalse(ModeController(env).status().presenting)
        assertFalse(env.listener)
        assertFalse(env.overlay)
    }

    @Test
    fun `ATIVADO sem a permissão especial segue normalmente (ela não é necessária)`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.SAMSUNG, secureSettings = false)
        val r = ModeController(env).select(NotificationMode.IOS)
        assertTrue(r.ok)
        assertTrue(r.missing.isEmpty())
        assertTrue(ModeController(env).status().presenting)
        assertTrue(r.notes.isEmpty())
    }

    // ---------- Erros ----------

    @Test
    fun `falha ao salvar mantém o modo anterior e não muda mais nada`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.IOS, systemPopupsOff = true, owned = true)
        env.failSave = true
        val r = ModeController(env).select(NotificationMode.SAMSUNG)
        assertFalse(r.ok)
        assertEquals(NotificationMode.IOS, r.mode)
        assertEquals(NotificationMode.IOS, env.storedMode)
        assertEquals(0, env.resetCalls)
        assertEquals(0, env.systemWrites)
        assertTrue(env.systemPopupsOff)
        assertTrue(r.notes.contains(ModeController.MSG_SAVE_FAILED))
    }

    @Test
    fun `falha ao fechar o cartão não desfaz a troca de modo`() {
        val env = FakeModeEnvironment(systemPopupsOff = true, owned = true)
        env.failReset = true
        val r = ModeController(env).select(NotificationMode.SAMSUNG)
        assertTrue(r.ok)
        assertEquals(NotificationMode.SAMSUNG, env.storedMode)
        assertTrue(r.notes.contains(ModeController.MSG_RESET_FAILED))
        // Mesmo com a falha, a restauração do que o app alterou continua acontecendo.
        assertFalse(env.systemPopupsOff)
    }

    // ---------- Alternância repetida ----------

    @Test
    fun `alternar muitas vezes termina sempre num estado coerente e nunca escreve no sistema`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.SAMSUNG)
        val c = ModeController(env)
        repeat(200) { i ->
            val target = if (i % 2 == 0) NotificationMode.IOS else NotificationMode.SAMSUNG
            val r = c.select(target)
            assertTrue(r.ok)
            assertEquals(target, env.storedMode)
            assertFalse(env.systemPopupsOff)
        }
        // Cada troca limpou o estado interno do serviço (sem sobras entre um modo e outro).
        assertEquals(200, env.resetCalls)
        assertEquals(0, env.systemWrites)
        assertEquals(NotificationMode.SAMSUNG, env.storedMode)
    }

    @Test
    fun `escolher duas vezes o mesmo modo é inofensivo`() {
        val env = FakeModeEnvironment(systemPopupsOff = true, owned = true)
        val c = ModeController(env)
        c.select(NotificationMode.SAMSUNG)
        val writes = env.systemWrites
        c.select(NotificationMode.SAMSUNG)
        assertEquals("não escreve no sistema de novo", writes, env.systemWrites)
        assertEquals(NotificationMode.SAMSUNG, env.storedMode)
        assertFalse(env.systemPopupsOff)
    }

    // ---------- Reinício ----------

    @Test
    fun `reiniciar o aparelho mantém o modo escolhido nos dois sentidos`() {
        val env = FakeModeEnvironment()
        ModeController(env).select(NotificationMode.SAMSUNG)

        // "Reinício": outro controlador sobre os mesmos dados salvos.
        val afterBoot = ModeController(env)
        assertEquals(NotificationMode.SAMSUNG, afterBoot.status().mode)
        val writes = env.systemWrites
        assertTrue(afterBoot.reconcile().ok)
        assertTrue(afterBoot.reconcile().ok)
        assertEquals(NotificationMode.SAMSUNG, env.storedMode)
        assertEquals("reaplicar é idempotente", writes, env.systemWrites)

        ModeController(env).select(NotificationMode.IOS)
        val afterSecondBoot = ModeController(env)
        assertEquals(NotificationMode.IOS, afterSecondBoot.status().mode)
        assertTrue(afterSecondBoot.reconcile().ok)
        assertEquals(NotificationMode.IOS, env.storedMode)
    }

    @Test
    fun `depois de reiniciar restaura o que uma troca interrompida deixou pelo meio`() {
        // O app foi encerrado no meio da troca: modo já salvo, mas o pop-up segue desligado.
        for (mode in NotificationMode.values()) {
            val env = FakeModeEnvironment(storedMode = mode, systemPopupsOff = true, owned = true)
            val r = ModeController(env).reconcile()
            assertTrue(r.ok)
            assertFalse(env.systemPopupsOff)
            assertFalse(env.owned)
        }
    }

    @Test
    fun `reconciliar respeita um ajuste restaurado por fora`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.IOS, owned = true, systemPopupsOff = false)
        ModeController(env).reconcile()
        assertFalse(env.owned)
        assertEquals("não briga com o usuário", 0, env.systemWrites)
    }

    @Test
    fun `reinício sem permissões mantém o modo escolhido e só mostra o estado`() {
        val env = FakeModeEnvironment(storedMode = NotificationMode.IOS, listener = false, overlay = false)
        val c = ModeController(env)
        val r = c.reconcile()
        assertEquals(NotificationMode.IOS, env.storedMode)
        assertEquals(listOf(Requirement.LISTENER_ACCESS, Requirement.OVERLAY_PERMISSION), r.missing)
        assertFalse(c.status().presenting)
    }

    // ---------- Botão "Restaurar os pop-ups do sistema" ----------

    @Test
    fun `restaurar pop-ups pede a permissão quando ela falta e não perde o registro`() {
        val env = FakeModeEnvironment(systemPopupsOff = true, owned = true, secureSettings = false)
        assertEquals(PopupsOutcome.NEEDS_PERMISSION, ModeController(env).restoreSystemPopups())
        assertTrue(env.owned)
        assertTrue(env.systemPopupsOff)
    }

    @Test
    fun `restaurar pop-ups religa o ajuste e limpa o registro`() {
        val env = FakeModeEnvironment(systemPopupsOff = true, owned = true)
        assertEquals(PopupsOutcome.DONE, ModeController(env).restoreSystemPopups())
        assertFalse(env.systemPopupsOff)
        assertFalse(env.owned)
        assertEquals(1, env.systemWrites)
    }

    @Test
    fun `restaurar quando já está ligado não escreve nada`() {
        val env = FakeModeEnvironment(systemPopupsOff = false, owned = true)
        assertEquals(PopupsOutcome.DONE, ModeController(env).restoreSystemPopups())
        assertFalse(env.owned)
        assertEquals(0, env.systemWrites)
    }
}
