package app.iosbanners

/**
 * Ambiente em memória para testar o ModeController sem Android. Os campos "salvos" (modo, marca de
 * propriedade, ajuste do sistema) sobrevivem a "reiniciar" (criar outro ModeController sobre o mesmo
 * objeto), como as preferências e o Settings.Global reais.
 */
class FakeModeEnvironment(
    var storedMode: NotificationMode = NotificationMode.IOS,
    var listener: Boolean = true,
    var overlay: Boolean = true,
    var secureSettings: Boolean = true,
    var systemPopupsOff: Boolean = false,
    var owned: Boolean = false
) : ModeEnvironment {

    var failSave = false
    var failReset = false
    var resetCalls = 0

    /** Quantas vezes o ajuste global foi escrito (a única escrita possível é restaurar). */
    var systemWrites = 0

    override fun mode(): NotificationMode = storedMode

    override fun saveMode(mode: NotificationMode): Boolean {
        if (failSave) return false
        storedMode = mode
        return true
    }

    override fun listenerGranted(): Boolean = listener
    override fun overlayGranted(): Boolean = overlay

    override fun popupsPermissionGranted(): Boolean = secureSettings
    override fun popupsDisabledInSystem(): Boolean = systemPopupsOff

    override fun restoreSystemPopups(): Boolean {
        if (!secureSettings) return false
        systemPopupsOff = false
        systemWrites++
        return true
    }

    override fun popupsOwnedByApp(): Boolean = owned
    override fun setPopupsOwnedByApp(value: Boolean) {
        owned = value
    }

    override fun resetPresentation() {
        resetCalls++
        if (failReset) throw IllegalStateException("falha simulada")
    }
}
