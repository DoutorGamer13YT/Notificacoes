package app.iosbanners

/**
 * Ambiente em memória para testar o ModeController sem Android. Os campos "salvos" (modo, chave
 * principal, marcas de pop-up, ajuste do sistema) sobrevivem a "reiniciar" (criar outro
 * ModeController sobre o mesmo objeto), como as preferências e o Settings.Global reais.
 */
class FakeModeEnvironment(
    var storedMode: NotificationMode = NotificationMode.IOS,
    var master: Boolean = true,
    var listener: Boolean = true,
    var overlay: Boolean = true,
    var secureSettings: Boolean = true,
    var systemPopupsOff: Boolean = false,
    var owned: Boolean = false,
    var wanted: Boolean = false
) : ModeEnvironment {

    var failSave = false
    var failReset = false
    var resetCalls = 0
    var systemWrites = 0

    override fun mode(): NotificationMode = storedMode

    override fun saveMode(mode: NotificationMode): Boolean {
        if (failSave) return false
        storedMode = mode
        return true
    }

    override fun masterEnabled(): Boolean = master
    override fun setMasterEnabled(value: Boolean) {
        master = value
    }

    override fun listenerGranted(): Boolean = listener
    override fun overlayGranted(): Boolean = overlay

    override fun popupsPermissionGranted(): Boolean = secureSettings
    override fun popupsDisabledInSystem(): Boolean = systemPopupsOff

    override fun setPopupsDisabledInSystem(disabled: Boolean): Boolean {
        if (!secureSettings) return false
        systemPopupsOff = disabled
        systemWrites++
        return true
    }

    override fun popupsOwnedByApp(): Boolean = owned
    override fun setPopupsOwnedByApp(value: Boolean) {
        owned = value
    }

    override fun popupsWanted(): Boolean = wanted
    override fun setPopupsWanted(value: Boolean) {
        wanted = value
    }

    override fun resetPresentation() {
        resetCalls++
        if (failReset) throw IllegalStateException("falha simulada")
    }
}
