package app.iosbanners

import android.app.Notification
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * O que pode virar cartão e, sobretudo, o que pode ser removido (cancelNotification). A regra de
 * segurança: chamadas, alarmes, navegação, mídia, serviços em primeiro plano, progresso, avisos de
 * tela cheia e o que o app de origem marcou como "não dispensável" nunca são removidos.
 */
class NotificationPolicyTest {

    private fun eval(
        category: String? = Notification.CATEGORY_MESSAGE,
        template: String? = null,
        own: Boolean = false,
        test: Boolean = false,
        summary: Boolean = false,
        ongoing: Boolean = false,
        fgs: Boolean = false,
        noClear: Boolean = false,
        insistent: Boolean = false,
        fullScreen: Boolean = false,
        bubble: Boolean = false,
        progress: Boolean = false,
        media: Boolean = false
    ) = NotificationPolicy.evaluate(
        NotificationTraits(
            isOwnPackage = own, isOwnTest = test, isGroupSummary = summary, isOngoing = ongoing,
            isForegroundService = fgs, isNoClear = noClear, isInsistent = insistent,
            hasFullScreenIntent = fullScreen, isBubble = bubble, isProgress = progress,
            hasMediaSession = media, category = category, template = template
        )
    )

    // ---------- As constantes conferem com o SDK ----------

    @Test
    fun `as categorias da política são exatamente as do Android`() {
        assertEquals(Notification.CATEGORY_CALL, NotificationPolicy.CAT_CALL)
        assertEquals(Notification.CATEGORY_ALARM, NotificationPolicy.CAT_ALARM)
        assertEquals(Notification.CATEGORY_NAVIGATION, NotificationPolicy.CAT_NAVIGATION)
        assertEquals(Notification.CATEGORY_TRANSPORT, NotificationPolicy.CAT_TRANSPORT)
        assertEquals(Notification.CATEGORY_PROGRESS, NotificationPolicy.CAT_PROGRESS)
        assertEquals(Notification.CATEGORY_SERVICE, NotificationPolicy.CAT_SERVICE)
        assertEquals(Notification.CATEGORY_SYSTEM, NotificationPolicy.CAT_SYSTEM)
        assertEquals(Notification.CATEGORY_STATUS, NotificationPolicy.CAT_STATUS)
        assertEquals(Notification.CATEGORY_STOPWATCH, NotificationPolicy.CAT_STOPWATCH)
        assertEquals(Notification.CATEGORY_LOCATION_SHARING, NotificationPolicy.CAT_LOCATION_SHARING)
        assertEquals(Notification.CATEGORY_WORKOUT, NotificationPolicy.CAT_WORKOUT)
        assertEquals(Notification.CATEGORY_REMINDER, NotificationPolicy.CAT_REMINDER)
        assertEquals(Notification.CATEGORY_EVENT, NotificationPolicy.CAT_EVENT)
        assertEquals(Notification.CATEGORY_MISSED_CALL, NotificationPolicy.CAT_MISSED_CALL)
    }

    // ---------- Notificação comum ----------

    @Test
    fun `mensagem comum vira cartão e a original pode ser removida`() {
        val d = eval()
        assertEquals(Treatment.BANNER_AND_REPLACE, d.treatment)
        assertTrue(d.showsBanner && d.mayCancelOriginal)
    }

    @Test
    fun `sem categoria também é comum`() {
        assertEquals(Treatment.BANNER_AND_REPLACE, eval(category = null).treatment)
    }

    @Test
    fun `categorias comuns de aviso continuam substituíveis`() {
        for (c in listOf(
            Notification.CATEGORY_MESSAGE, Notification.CATEGORY_EMAIL, Notification.CATEGORY_SOCIAL,
            Notification.CATEGORY_PROMO, Notification.CATEGORY_RECOMMENDATION, Notification.CATEGORY_ERROR
        )) {
            assertEquals(c, Treatment.BANNER_AND_REPLACE, eval(category = c).treatment)
        }
    }

    // ---------- Nunca tocar ----------

    @Test
    fun `categorias protegidas nunca viram cartão nem são removidas`() {
        for (c in listOf(
            Notification.CATEGORY_CALL, Notification.CATEGORY_MISSED_CALL, Notification.CATEGORY_ALARM,
            Notification.CATEGORY_NAVIGATION, Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_SERVICE, Notification.CATEGORY_SYSTEM, Notification.CATEGORY_STATUS,
            Notification.CATEGORY_STOPWATCH, Notification.CATEGORY_LOCATION_SHARING, Notification.CATEGORY_WORKOUT
        )) {
            val d = eval(category = c)
            assertEquals(c, Treatment.IGNORE, d.treatment)
            assertFalse(c, d.mayCancelOriginal)
        }
    }

    @Test
    fun `serviço em primeiro plano e em andamento nunca são tocados`() {
        assertEquals(Treatment.IGNORE, eval(fgs = true).treatment)
        assertEquals(Treatment.IGNORE, eval(ongoing = true).treatment)
    }

    @Test
    fun `resumo de grupo nunca é tocado`() {
        assertEquals(Treatment.IGNORE, eval(summary = true).treatment)
    }

    @Test
    fun `aviso de tela cheia e progresso nunca são tocados`() {
        assertEquals(Treatment.IGNORE, eval(fullScreen = true).treatment)
        assertEquals(Treatment.IGNORE, eval(progress = true).treatment)
    }

    @Test
    fun `mídia é reconhecida pela sessão, pela categoria e pelo modelo`() {
        assertEquals(Treatment.IGNORE, eval(media = true).treatment)
        assertEquals(Treatment.IGNORE, eval(category = Notification.CATEGORY_TRANSPORT).treatment)
        assertEquals(Treatment.IGNORE, eval(template = Notification.MediaStyle::class.java.name).treatment)
        assertEquals(
            Treatment.IGNORE,
            eval(template = Notification.DecoratedMediaCustomViewStyle::class.java.name).treatment
        )
    }

    @Test
    fun `chamada é reconhecida pela categoria e pelo modelo CallStyle`() {
        assertEquals(Treatment.IGNORE, eval(category = Notification.CATEGORY_CALL).treatment)
        // Mesmo que o app declare outra categoria, o modelo CallStyle a denuncia.
        assertEquals(
            Treatment.IGNORE,
            eval(category = Notification.CATEGORY_MESSAGE, template = Notification.CallStyle::class.java.name)
                .treatment
        )
    }

    @Test
    fun `modelos de mensagem e de texto longo não são confundidos com mídia ou chamada`() {
        assertEquals(
            Treatment.BANNER_AND_REPLACE,
            eval(template = Notification.MessagingStyle::class.java.name).treatment
        )
        assertEquals(
            Treatment.BANNER_AND_REPLACE,
            eval(template = Notification.BigTextStyle::class.java.name).treatment
        )
    }

    // ---------- Cartão sim, remoção não ----------

    @Test
    fun `o que o app marcou como não dispensável vira cartão mas a original fica`() {
        val d = eval(noClear = true)
        assertEquals(Treatment.BANNER_ONLY, d.treatment)
        assertTrue(d.showsBanner)
        assertFalse(d.mayCancelOriginal)
    }

    @Test
    fun `som insistente, bolha, lembrete e evento mantêm a original`() {
        assertEquals(Treatment.BANNER_ONLY, eval(insistent = true).treatment)
        assertEquals(Treatment.BANNER_ONLY, eval(bubble = true).treatment)
        assertEquals(Treatment.BANNER_ONLY, eval(category = Notification.CATEGORY_REMINDER).treatment)
        assertEquals(Treatment.BANNER_ONLY, eval(category = Notification.CATEGORY_EVENT).treatment)
    }

    // ---------- Próprio app ----------

    @Test
    fun `notificações do próprio app são ignoradas, exceto a de teste`() {
        assertEquals(Treatment.IGNORE, eval(own = true).treatment)
        assertEquals(Treatment.IGNORE, eval(own = true, category = null).treatment)
        assertEquals(Treatment.BANNER_AND_REPLACE, eval(own = true, test = true).treatment)
    }

    @Test
    fun `a marca de teste sem ser do próprio app não vale nada`() {
        // O serviço só põe isOwnTest quando o pacote é o do app; aqui garantimos que a política não
        // abre exceção para um app qualquer que copie a marca.
        assertEquals(Treatment.BANNER_AND_REPLACE, eval(own = false, test = true).treatment)
        assertEquals(Treatment.IGNORE, eval(own = false, test = true, ongoing = true).treatment)
    }

    // ---------- Invariante, varrendo todas as combinações ----------

    @Test
    fun `invariante - se há qualquer sinal de risco a original jamais é removida`() {
        val categories = listOf(
            null, "msg", "email", "social", "call", "missed_call", "alarm", "navigation", "transport",
            "progress", "service", "sys", "status", "stopwatch", "location_sharing", "workout",
            "reminder", "event", "promo"
        )
        val templates = listOf(
            null,
            Notification.MessagingStyle::class.java.name,
            Notification.MediaStyle::class.java.name,
            Notification.DecoratedMediaCustomViewStyle::class.java.name,
            Notification.CallStyle::class.java.name
        )
        var checked = 0
        for (mask in 0 until (1 shl 8)) {
            fun bit(i: Int) = (mask shr i) and 1 == 1
            for (c in categories) for (t in templates) {
                val traits = NotificationTraits(
                    isGroupSummary = bit(0), isOngoing = bit(1), isForegroundService = bit(2),
                    isNoClear = bit(3), isInsistent = bit(4), hasFullScreenIntent = bit(5),
                    isBubble = bit(6), isProgress = bit(7), hasMediaSession = false,
                    category = c, template = t
                )
                val d = NotificationPolicy.evaluate(traits)
                val risky = mask != 0 ||
                    c in setOf("call", "missed_call", "alarm", "navigation", "transport", "progress", "service",
                        "sys", "status", "stopwatch", "location_sharing", "workout", "reminder", "event") ||
                    t == Notification.MediaStyle::class.java.name ||
                    t == Notification.DecoratedMediaCustomViewStyle::class.java.name ||
                    t == Notification.CallStyle::class.java.name
                if (risky) assertFalse("não pode remover: mask=$mask cat=$c tpl=$t", d.mayCancelOriginal)
                else assertTrue("comum deve ser substituível: cat=$c tpl=$t", d.mayCancelOriginal)
                // Remoção permitida implica cartão; "ignorar" implica não remover.
                if (d.mayCancelOriginal) assertTrue(d.showsBanner)
                if (!d.showsBanner) assertFalse(d.mayCancelOriginal)
                checked++
            }
        }
        assertEquals(256 * categories.size * templates.size, checked)
    }

    @Test
    fun `sessão de mídia ativa bloqueia em qualquer combinação`() {
        for (c in listOf(null, "msg", "email")) {
            val d = NotificationPolicy.evaluate(NotificationTraits(hasMediaSession = true, category = c))
            assertEquals(Treatment.IGNORE, d.treatment)
        }
    }

    // ---------- Ações ----------

    private fun a(title: String?, intent: Boolean = true, text: Boolean = false) = ActionInfo(title, intent, text)

    @Test
    fun `ações simples viram botões, na ordem original`() {
        assertEquals(listOf(0, 1), ActionPolicy.select(listOf(a("Marcar como lida"), a("Silenciar"))))
    }

    @Test
    fun `ações de resposta por texto ficam de fora (o cartão não tem campo de texto)`() {
        assertEquals(listOf(1), ActionPolicy.select(listOf(a("Responder", text = true), a("Marcar como lida"))))
    }

    @Test
    fun `ações sem título ou sem intenção ficam de fora`() {
        assertEquals(
            listOf(3),
            ActionPolicy.select(listOf(a(null), a("   "), a("Abrir", intent = false), a("Arquivar")))
        )
    }

    @Test
    fun `no máximo três ações`() {
        val many = (1..6).map { a("Ação $it") }
        assertEquals(listOf(0, 1, 2), ActionPolicy.select(many))
        assertEquals(3, ActionPolicy.MAX_ACTIONS)
    }

    @Test
    fun `lista vazia não gera botões`() {
        assertTrue(ActionPolicy.select(emptyList()).isEmpty())
    }
}
