import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.iosbanners"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.iosbanners"
        minSdk = 29
        targetSdk = 34
        versionCode = 3
        versionName = "0.3.0-debug"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

// O app não usa bibliotecas externas (só APIs da plataforma Android). O JUnit abaixo é só para os
// testes unitários em app/src/test e não entra no APK.
dependencies {
    testImplementation("junit:junit:4.13.2")
}
