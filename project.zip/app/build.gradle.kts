import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.iosbanners"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.iosbanners"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-debug"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

// Sem dependências externas: o app usa apenas APIs da plataforma Android.
