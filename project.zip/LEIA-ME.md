# iOS Banners (projeto Android em Kotlin)

Cartão de notificação em estilo iOS para as **notificações reais** do Android, via `NotificationListenerService`.

## Estado real deste projeto (leia primeiro)

- **O APK não foi gerado.** O ambiente onde o código foi escrito bloqueava o acesso aos repositórios do Google/Maven/Gradle, então o Gradle (plugin do Android, resources, lint e empacotamento) **não rodou**. Este pacote traz o projeto completo e um build automático na nuvem.
- **O que foi verificado de fato (versão 0.3.0):** todo o código Kotlin (inclusive `NotificationService`, `MainActivity` e o overlay) foi compilado com o compilador Kotlin 2.0.21 contra o `android.jar` real da API 35, **sem erros**; e os **70 testes unitários JUnit foram executados e passaram**. Isso não substitui o `assembleDebug` (que ainda pode apontar problemas de recursos/lint) nem o teste em aparelho.
- **Nada foi testado em aparelho**, nem no Galaxy A54 5G com One UI 8.5.
- **O AOD nativo não é suportado** (veja abaixo).
- O visual é **inspirado** nas notificações do iOS, com medidas e cores aproximadas. A fonte é a do sistema (a SF Pro é da Apple). Não consegui confirmar detalhes visuais específicos do iOS 27 para notificações.

## O que o app faz

- Lê notificações reais dos apps escolhidos (padrão: WhatsApp, WhatsApp Business, Instagram, Discord).
- Mostra um cartão no topo da tela (janela de sobreposição) com ícone ou foto, remetente, mensagem, app de origem e "agora". Entra e sai com animação; deslize para cima para dispensar; toque abre o app de origem.
- Trata conversas (última mensagem e remetente), ignora resumos de grupo, mídia, progresso e serviços, e evita repetir a mesma atualização.
- Opções: cartão escuro/claro, desfoque (experimental), **modo de notificação exclusiva** (ligado por padrão, veja abaixo), só o cartão com a tela apagada (experimental, ligado por padrão).
- Mostra o crédito **@vitinhjkjkk** em destaque no topo da tela principal.
- Tela com status das permissões, prévia, notificação de teste e diagnóstico.
- Sem permissão de internet: nada do conteúdo sai do aparelho nem é gravado.

## AOD (Always On Display)

Pelo que pude apurar, o AOD da Samsung é desenhado pelo sistema e mostra só ícones das notificações não lidas. Os complementos conhecidos (temas de AOD na Galaxy Store e o Clockface do Good Lock) mudam apenas o relógio. Não encontrei API pública do Android ou da One UI que permita a um app mudar a aparência das notificações no AOD, e janelas de sobreposição não aparecem com a tela apagada. Por isso **este app não altera o AOD**.

A alternativa mais próxima, ligada por padrão (opção "Só o cartão com a tela apagada"): quando a notificação chega com a tela apagada, uma Activity (`setShowWhenLocked` + `setTurnScreenOn`) acende a tela com brilho baixo, sem barras do sistema, com fundo preto puro e só o cartão. Em tela AMOLED o preto fica apagado, então visualmente sobra só a notificação, sem relógio. O cartão fica na **mesma posição do banner da tela ligada** (mesma conta em `bannerTopOffset()`, em `Ui.kt`), e tocar fora dele fecha.

Isso **não é o AOD**: a tela fica realmente ligada até o tempo limite de tela do sistema (ou 12 segundos), o que gasta mais bateria que o AOD. Um app comum não consegue apagar a tela sozinho nem desenhar com ela apagada. Depende da permissão de sobreposição e das regras de abertura em segundo plano do Android 16, e **não foi verificado**.

## Como gerar o APK

### Opção A: só pelo celular (GitHub Actions)

1. Crie um repositório no GitHub (público, para o link de download funcionar sem login).
2. Em **Add file → Upload files**, envie o arquivo `project.zip` (sem extrair). Se o repositório ainda tiver o `project-modificado.zip` antigo, pode deixar: o workflow compila o `project.zip` primeiro (e, na falta dele, o `project-modificado.zip` ou o projeto já extraído na raiz).
3. Em **Add file → Create new file**, nomeie como `.github/workflows/build-apk.yml` e cole o conteúdo do arquivo `.github/workflows/build-apk.yml` que acompanha este pacote. Confirme com **Commit**.
4. Abra a aba **Actions**; o build roda sozinho (ou use **Run workflow**). Leva alguns minutos.
5. Quando terminar, abra **Releases** no repositório e baixe `ios-banners-debug.apk`.

O workflow também roda os testes unitários (passo "Testes unitários", que **não bloqueia** o APK: se falharem, o passo fica com aviso e o relatório vai no artefato `relatorio-testes-unitarios`).

Se o build falhar, abra o passo "Compilar" no log, copie as mensagens de erro e envie para corrigirmos.

### Opção B: Android Studio (computador)

Abra a pasta do projeto, aguarde a sincronização e use **Build → Build APK(s)**. O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`. Pela linha de comando: `./gradlew assembleDebug` (JDK 17); para os testes unitários: `./gradlew testDebugUnitTest`.

O APK gerado é de **depuração**, assinado com a chave de debug.

## Instalar e ativar no Galaxy A54

1. Abra o APK pelo app Arquivos ou Downloads. Permita "instalar apps desconhecidos" para quem pedir e, se o Play Protect avisar, toque em "Instalar mesmo assim".
2. Abra **iOS Banners**.
3. Toque em **Conceder acesso às notificações**, escolha **iOS Banners** e ative.
4. Se o Android disser "configuração restrita": toque em **Informações do app (configurações restritas)**, nos três pontos e em **Permitir configurações restritas**; depois repita o passo 3.
5. Toque em **Permitir exibir sobre outros apps** e ative.
6. Em **Substituir notificações nativas**, escolha **ATIVADO** e use **Enviar notificação de teste** com o celular desbloqueado. Por padrão o cartão vale para **todos os apps** (chave "Todos os apps"); para escolher só alguns, desligue a chave e use **Escolher aplicativos**. Nunca são tratados: ligações, alarmes, navegação, avisos de tela cheia, mídia, serviços em andamento e os pacotes `android` e `com.android.systemui`. Atenção: com "todos os apps" e o modo exclusivo ligados, a original de qualquer app que faça pop-up é removida depois do cartão (códigos de verificação, por exemplo); use o ajuste por canal (botão "Desativar o pop-up deste canal") para manter a original na central, ou desligue o modo exclusivo.

As chaves do app têm polegar branco e trilho azul (ligado) ou cinza (desligado), independentes do tema do sistema.
7. Para não ver dois pop-ups, deixe ligado o **Modo de notificação exclusiva** (padrão) e, na seção dele, use o botão **Desativar o pop-up deste canal** de cada canal listado: assim a notificação original fica só na central, com som e respostas rápidas, e o único pop-up é o cartão.
8. Se o aviso parar de chegar com o tempo, toque em **Ajustar uso de bateria** e permita "Sem restrição" e, nas configurações de bateria da Samsung, tire o app de "apps em suspensão".

## Limites do Android que continuam valendo

- Um app não consegue impedir que a notificação original apareça: o Android só deixa o `NotificationListenerService` cancelá-la **depois** de publicada, então o pop-up original pode piscar antes do cartão. Não existe API pública para interceptá-la antes (isso só vale para o assistente de notificações do sistema).
- O app não lê a opção "ocultar conteúdo sensível" nem "notificações na tela de bloqueio" do sistema, nem a visibilidade por app que você define nas configurações (`Ranking.getVisibilityOverride` é API oculta e não existe no SDK); por isso a prévia com PIN/biometria é uma opção sua, desligada por padrão. O app lê só a visibilidade da notificação e a do canal.
- Se o Android recusar abrir a tela do cartão em segundo plano (restrições do Android 14+), nada aparece e a original **não** é removida, então a original continua na tela de bloqueio como o app de origem a montou (o app não controla o conteúdo dela).
- Entrega depende do Android, da One UI e do app de origem: não existe atraso zero.
- Recuperação: depois de encerrado pelo sistema por falta de memória, ou após reiniciar o aparelho, o próprio Android religa o serviço se o acesso às notificações estiver concedido. Depois de **Forçar parada**, o Android só religa quando você abre o app de novo. Com o acesso revogado, o app não funciona até você conceder de novo.

## Pontos não verificados

- Compilação e execução em qualquer aparelho.
- Comportamento do desfoque em janela de sobreposição na One UI 8.5 (pode borrar a janela inteira).
- Se o Android 16 deixa o app acender a tela e abrir o cartão em segundo plano, e se o toque no cartão abre o app de origem depois de desbloquear.
- Se o brilho baixo (20%) fica legível para você; está na constante `BRIGHTNESS` de `LockCardActivity.kt`.
- Se o cartão da tela bloqueada fica exatamente na mesma altura do banner em todos os aparelhos (a conta é a mesma, mas a medida real depende da One UI).
- Se a remoção da notificação original no pop-up do sistema acontece sem piscar na One UI 8.5.
- Se o Android 15/16 permite abrir a `LockCardActivity` a partir do serviço em segundo plano com a tela apagada.
- Se o campo de detecção do AOD do sistema (`aod_mode`) existe na sua versão; o diagnóstico mostra "não detectado" se não existir.
- Foto do contato e agrupamento em cada app (dependem de como o app de origem monta a notificação).

## Substituir notificações nativas (ATIVADO / DESATIVADO) — versão 0.3.0

Na tela principal, a seção **Substituir notificações nativas** tem duas opções (○/●). A escolha é única e persistente (as antigas "Modo de notificações" e a chave "Ativar banners estilo iOS" foram unificadas; quem atualiza mantém o que via: só vira ATIVADO se estava no modo iOS **e** com a chave ligada; instalação nova começa DESATIVADO).

- **ATIVADO:** as notificações aparecem pelo iOS Banners. A original continua sendo recebida em segundo plano (é dela que o cartão é montado) e só é dispensada com `cancelNotification(key)`, **uma notificação por vez**, depois que o cartão apareceu, quando ela faria pop-up (modo exclusivo) e quando a política abaixo permite.
- **DESATIVADO:** o app não lê, não mostra e não remove nada: vale o comportamento nativo da Samsung. Fecha o cartão na tela e descarta o trabalho pendente.

**Estado, sempre visível.** Abaixo das opções a tela diz: DESATIVADO (nada removido); ATIVADO funcionando; ou ATIVADO **selecionado, mas faltando** acesso às notificações ou exibir sobre outros apps (nada é exibido nem removido e as originais seguem normais). Ao escolher ATIVADO sem permissão, aparece um aviso com botão para as configurações oficiais do Android; o app nunca concede permissão sozinho e não pede root.

**O que ele captura.** Título, texto (incluindo a última mensagem e o remetente de conversas), ícone do app, foto do contato, intenção de abrir o app, **ações** (até 3, sem as de resposta por texto) e **atualizações**: a mesma notificação (mesma chave) atualiza o cartão que já está na tela; se o app de origem a cancelar (conversa aberta em outro aparelho, por exemplo), o cartão dela sai da tela. No banner, deslize para **baixo** para ver as ações; toque no cartão abre o app de origem. As notificações do próprio app são ignoradas (exceto a de teste).

**Quando a original pode ser removida (`NotificationPolicy`, testada).**
- Nunca tocadas (sem cartão e sem remoção): chamadas e chamadas perdidas, alarmes, navegação, cronômetro, mídia (`MediaStyle`, sessão de mídia, categoria transporte), `CallStyle`, compartilhamento de localização, treino, progresso, serviços em primeiro plano ou em andamento, resumos de grupo, avisos de tela cheia, categorias de sistema/serviço/status.
- Viram cartão, mas a original **fica**: o que o app marcou como não dispensável (`FLAG_NO_CLEAR`), som insistente, bolhas de conversa, lembretes e eventos.
- Notificação comum (mensagem, e-mail, social...): vira cartão e a original pode sair, ainda sujeita ao modo exclusivo (só se faria pop-up) e a `RemovalPolicy`.

**`cancelNotification(String key)` — o que foi apurado.** A API pública existe no `NotificationListenerService` (assinaturas conferidas no `android.jar` da API 35): `cancelNotification(String)`, `cancelNotifications(String[])`, `cancelAllNotifications()` e `snoozeNotification(String, long)`. Ela só age depois de a notificação ser publicada (não há como interceptar antes), então o pop-up original **pode piscar** antes do cartão. O app usa só a variante por chave, e só nas condições acima; **nunca** `cancelAllNotifications()`. A documentação oficial completa da classe não pôde ser lida nesta sessão, então o comportamento exato do sistema para notificações em andamento/serviço em primeiro plano (que o app já exclui por conta própria) não foi confirmado em aparelho.

**Pop-ups do sistema: este app não os desliga.** Versões anteriores tinham um botão que gravava `heads_up_notifications_enabled = 0` (pop-up de TODOS os apps, inclusive chamadas), e o modo iOS o religava sozinho. Isso foi **removido**. `WRITE_SECURE_SETTINGS` não é uma forma comprovada nem segura de "desativar notificações" e o app não presume isso: a permissão só é **verificada** (aparece no diagnóstico) e, se concedida, serve para **restaurar** o ajuste caso uma versão anterior o tenha desligado (o botão "Restaurar os pop-ups do sistema" só aparece nesse caso; sem a permissão, o app mostra o comando adb). O app nunca pede essa permissão em tempo de execução (o Android só a concede por adb).

**Duplicidade e troca repetida.** `CardLedger` controla repetição e é **zerado a cada troca de modo** (sem isso, uma notificação que ficou na central durante o DESATIVADO poderia ser tratada, ao voltar ao ATIVADO, como "já virou cartão" e ser removida sem cartão nenhum). Uma republicação idêntica de algo que já virou cartão só remove a original de novo, em silêncio.

**Aplicação e persistência.** A escolha é gravada na hora (`commit()` síncrono) e aplicada imediatamente: o serviço consulta o modo a cada notificação e também antes de mostrar o cartão e de remover a original. Depois de reiniciar o aparelho, o Android religa o `NotificationListenerService` (se o acesso estiver concedido) e `onListenerConnected` reaplica o modo salvo (`ModeController.reconcile()`). Não há receptor de boot.

**Limites reais (do Android e da One UI, não do app).**
- O modo ATIVADO **não remove todas as notificações nativas**, nem promete substituição universal: só as comuns e permitidas. Se o app de origem republicar a notificação com outra chave, ou se a One UI recusar o cancelamento, a original continua aparecendo e nada é forçado.
- A original só pode ser dispensada **depois** de publicada: o pop-up original pode piscar antes do cartão.
- Um app comum não consegue desativar as notificações nem os canais de outros apps; só o usuário. Este app não usa `cancelAllNotifications()`, não desativa nem altera canais e não mexe em chamadas, mídia nem serviços em primeiro plano.
- Ao remover a original, some também o que dependia dela na central: histórico daquela notificação e respostas rápidas. Por isso há o modo exclusivo (desligável) e o ajuste por canal.
- **Respostas por texto** (RemoteInput) não são reapresentadas no cartão (ele não tem campo de texto): toque no cartão para abrir o app. As demais ações (até 3) sim, só no banner da tela desbloqueada.
- Notificações já dispensadas **não voltam** à central ao DESATIVAR: o Android não deixa um app republicar notificações de outros apps. As novas chegam normalmente.
- Não verificado em aparelho (One UI 8.5): se o `cancelNotification` é aceito para cada tipo de app, o piscar do pop-up original, e o gesto de deslizar para ver as ações.

**Testes (JUnit, na JVM, em `app/src/test`) — 70 testes, executados e aprovados.** `ModeControllerTest` (os dois modos, alternância repetida 200 vezes, reinício, ausência de permissões, falha ao salvar, nunca desligar o ajuste global, restauração), `NotificationModeTest` (migração das preferências antigas), `NotificationPolicyTest` (o que nunca é removido, incluindo varredura de 256 combinações de sinais × categorias × modelos; confere as categorias contra as constantes reais do SDK; seleção de ações), `CardLedgerTest` e `RemovalPolicyTest`. Também foi feito teste de mutação (quebrar a regra de propósito e ver os testes falharem). Cobrem a lógica pura; **a interface, o serviço real e o Android não têm teste automatizado.** Para rodar: `./gradlew testDebugUnitTest`.

## Modo de notificação exclusiva (versão anterior; segue valendo dentro do modo ATIVADO)

**O que ele faz.** O serviço lê, pelo `Ranking` do próprio listener (APIs públicas), a importância real da notificação e o canal dela. Importância alta (`IMPORTANCE_HIGH` ou mais, fora do "Não perturbe") significa pop-up original. Só nesse caso, depois que o cartão apareceu na tela, a original é removida. Em canais sem pop-up (por exemplo `IMPORTANCE_DEFAULT`: som, sem pop-up) a original **não** é removida: continua na central, com som e respostas rápidas, e não há pop-up duplicado a evitar. Sem ranking disponível, o app assume pop-up (lado seguro: evita duplicar).

**Correção definitiva, pelo usuário.** Os canais com pop-up ativo aparecem na seção "Notificação exclusiva", cada um com um botão que abre o ajuste do canal no sistema (`ACTION_CHANNEL_NOTIFICATION_SETTINGS`, com a página do app como alternativa). Ao deixar o canal sem pop-up, a original passa a ficar só na central e o app para de removê-la. Só o usuário pode mudar o canal de outro app. A lista guarda apenas pacote, id e nome do canal (nunca o conteúdo; canais de conversa são agrupados como "Conversas", sem nomes de contatos).

**Permissões.** Só as que o app já usa: acesso às notificações e exibir sobre outros apps. Ao ligar o modo sem elas, o app abre a tela do sistema da que falta e mostra o estado em vermelho. Sem as permissões nada é exibido e nada é removido. Não há permissão nova no manifesto.

**Segundo plano.** Tudo roda no `NotificationListenerService`; a tela do app não precisa ficar aberta.

**O que não existe (analisado, não implementado):**
- Não há API pública para um app desligar só os pop-ups originais de todos os apps. `updateNotificationChannel` e `getNotificationChannels` do listener exigem um dispositivo companion associado (relógio, por exemplo); o assistente de notificações é um serviço do sistema; a permissão `WRITE_SETTINGS` só altera ajustes do próprio sistema (`Settings.System`) e não controla notificações de outros apps.
- O "Não perturbe" com efeitos visuais suprimidos exigiria acesso à política de notificações e silenciaria o som: não implementado.
- O ajuste global `heads_up_notifications_enabled` (não é API documentada do SDK) **não é mais gravado por este app** (veja "Pop-ups do sistema: este app não os desliga" acima). Se estiver desligado (por uma versão antiga ou por você), o app só o lê: sem pop-up original não há o que remover, e o modo exclusivo não remove nada. Para restaurar à mão: `adb shell settings put global heads_up_notifications_enabled 1`.

**Limites que continuam.** O pop-up original só pode ser removido **depois** de aparecer, então pode piscar. Remover uma notificação pode cortar o som dela e tirá-la das respostas rápidas (por isso a remoção só vale para canais com pop-up ativo). Dois avisos seguidos de apps diferentes: o cartão do primeiro é substituído pelo do segundo.

**Verificado só por leitura do código:** referências, imports, chaves e parênteses, e as APIs usadas. **Precisa de teste em aparelho:** se a One UI reflete no `Ranking` a opção de pop-up do canal, e se o botão abre a tela certa do canal de outro app.

## Correção da duplicação (versão anterior, não compilada nem testada em aparelho)

- **Causa:** o app remove a notificação original depois que o cartão aparece. Se o app de origem (ex.: WhatsApp) republicava exatamente o mesmo evento (mesma chave, mesmo conteúdo) logo depois, o filtro de repetição retornava sem remover a original de novo. Resultado: o cartão e a original voltavam juntos, duas notificações para o mesmo evento.
- **Correção:** o serviço guarda quais chaves já tiveram o cartão confirmado (`cardedKeys`). Uma republicação idêntica dessas chaves só remove a original de novo, em silêncio, sem mostrar outro cartão. Um evento novo (conteúdo ou hora diferente) continua gerando cartão normalmente, e notificações diferentes, mesmo com texto igual, têm chaves diferentes e não são bloqueadas.
- **Proteção antecipada:** a republicação idêntica (mesma chave e mesmo "when") de uma notificação já convertida em cartão é removida já na chegada, antes da fila de trabalho, para a original não ficar visível. Se o conteúdo mudar, o "when" normalmente muda e o cartão novo segue o caminho normal.
- **Não é atraso:** nenhum tempo de espera foi adicionado.
- **Limite do Android:** o pop-up original pode piscar por instantes antes de o app conseguir removê-la (o listener só age depois que a notificação é publicada). Se a original ficar visível por mais de um segundo, a causa é outra e vale enviar o log.

## Mudanças da atualização de notificações (não compiladas, não testadas em aparelho)

- **Atraso:** a leitura da notificação (e das fotos) saiu da thread principal: agora roda numa thread de trabalho única, na ordem de chegada, e só o desenho do cartão volta à thread principal. Em conversas com muitas mensagens acumuladas, só a mensagem mais recente é lida do pacote (antes todas eram interpretadas). Na tela bloqueada/apagada, a espera fixa de 700 ms antes de remover a original virou "remove assim que a janela ganha foco com a tela acesa", mantendo os 700 ms só como garantia.
- **Duplicação:** a mesma notificação reenviada pelo app com outra hora, mas mesmo conteúdo, não gera outro cartão (em conversas a identidade é a hora da última mensagem). Se um cartão da tela bloqueada substituir outro ainda não confirmado, a original do anterior não é removida. A notificação de teste sempre é removida depois do cartão e expira sozinha em 30 s.
- **Tela bloqueada:** o cartão mostra só o nome (contato ou app), o ícone e uma prévia de uma linha da mensagem mais recente, com no máximo 120 caracteres e reticências. Texto expandido de apps de chat que acumula o histórico passa a usar só a última linha. Não repete o texto no título e no corpo. Com a opção de tela apagada ligada, o cartão agora também vale para tela acesa e bloqueada.
- **Privacidade:** com PIN/padrão/biometria, notificações secretas não aparecem; as privadas mostram só o nome do app e "Nova mensagem" (ou o texto público definido pelo próprio app), sem foto do contato, a menos que você ligue **Prévia com o aparelho protegido por PIN/biometria**.
- **Recuperação:** o serviço só pede reconexão se o acesso às notificações ainda estiver concedido; o estado `connected` é limpo ao destruir o serviço; a tela do cartão se fecha ao desbloquear o aparelho.
- O botão "Enviar notificação de teste" continua existindo (só envia quando você toca nele).

## Mudanças da versão anterior (não compiladas, não testadas)

- **Sem duplicação:** "Remover a notificação original" agora vem ligada. A original só é removida depois que o cartão realmente apareceu (banner na tela ligada; `LockCardActivity` com a tela já acesa), e nunca para apps não marcados nem para notificações de serviço/ongoing/mídia/progresso. A mesma notificação (mesma chave) atualiza o cartão que já está na tela em vez de criar outro.
- **Segundo plano:** o serviço pede reconexão ao sistema em `onListenerDisconnected`; o botão de bateria pede "Sem restrição" direto (permissão `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`) e cai para a lista do sistema se não for possível. Não há serviço em primeiro plano: o `NotificationListenerService` já é mantido pelo sistema, sem notificação persistente.
- **Bateria:** o serviço decide se algo pode ser exibido antes de extrair qualquer coisa; imagens só são carregadas depois de descartar repetições; rótulos de apps e lista de apps monitorados ficam em cache; tela bloqueada fica ligada por até 12 s (antes 20 s).
- **Posição na tela bloqueada:** banner e cartão da tela bloqueada usam a mesma conta de topo; a janela da `LockCardActivity` passa a ignorar o recorte da câmera (`SHORT_EDGES`) e, no Android 10, fixa o layout a partir do topo físico; a posição aleatória foi removida.
- **Crédito:** @vitinhjkjkk em destaque na tela principal.

## Estrutura

- `NotificationService.kt`: recebe e filtra notificações, extrai conteúdo, decide onde exibir.
- `BannerOverlay.kt` e `NotificationCardView.kt`: janela de sobreposição, animações, gesto e visual do cartão.
- `LockCardActivity.kt`: alternativa experimental na tela bloqueada.
- `MainActivity.kt` e `AppPickerActivity.kt`: configuração, prévia, teste, diagnóstico e seleção de apps.
- `Prefs.kt`, `CardData.kt`, `Ui.kt`: configurações, modelo de dados e utilitários.
- `PopupChannels.kt`: lista dos canais de outros apps com pop-up original ativo (modo exclusivo).
- `NotificationMode.kt`, `ModeController.kt`, `NotificationPolicy.kt` (o que pode ser trocado/removido e quais ações viram botão), `RemovalPolicy.kt`, `CardLedger.kt`: lógica do ATIVADO/DESATIVADO em Kotlin puro (sem Android), testada em `app/src/test`.
- `AndroidModeEnvironment.kt`: liga essa lógica às preferências, permissões e ao serviço reais.
